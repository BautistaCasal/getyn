﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Core.Domain.Models
{
    public class Event: BaseModel
    {
        [Required]
        public string Title { get; set; }

        public string Description { get; set; }

        public DateTime? ExpirationDate { get; set; }

        public int? MinAge { get; set; }

        public int? MaxAge { get; set; }

        public int? MinParticipants { get; set; }

        public int? MaxParticipants { get; set; }

        public string MainImageURL { get; set; }

        public string Tags { get; set; }

        public string Location { get; set; }

        [Required]
        public int UserCreatorId { get; set; }

        public virtual User UserCreator { get; set; }

        [Required]
        public int CategoryId { get; set; }

        public virtual Category Category { get; set; }

        public virtual ICollection<Group> GroupsParticipants { get; set; }

        public virtual ICollection<User> UsersParticipants { get; set; }

        public virtual ICollection<ImageInEvent> ImagesInEvent { get; set; }
    }
}
