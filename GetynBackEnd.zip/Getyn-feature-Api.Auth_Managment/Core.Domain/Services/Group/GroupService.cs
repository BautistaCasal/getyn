﻿using AutoMapper;
using Core.Logger.Interfaces;
using Core.Repository.Services.Group;

namespace Core.Domain.Services.Group
{
    public class GroupService : BaseService<GroupRepository, Repository.Entities.Group, Models.Group>, IGroupService
    {
        public GroupService(IGroupRepository baseRepository, IMapper mapper, ILogService logger) : base(baseRepository, mapper, logger)
        {
        }
    }
}
