﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Core.Dtos.Event.Request
{
    public class CreateEventRequestDto
    {
        [Required]
        public string Title { get; set; }

        public string Description { get; set; }

        public DateTime? ExpirationDate { get; set; }

        public int? MinAge { get; set; }

        public int? MaxAge { get; set; }

        public int? MinParticipants { get; set; }

        public int? MaxParticipants { get; set; }

        public string MainImageURL { get; set; }

        public string Tags { get; set; }

        public string Location { get; set; }

        [Required]
        public int UserCreatorId { get; set; }

        [Required]
        public int CategoryId { get; set; }
    }
}
