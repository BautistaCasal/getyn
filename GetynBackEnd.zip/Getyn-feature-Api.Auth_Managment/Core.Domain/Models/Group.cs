﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain.Models
{
    public class Group: BaseModel
    {
        [Required]
        public string Title { get; set; }

        public string Description { get; set; }

        public string MainImageURL { get; set; }

        public int UserCreatorId { get; set; }
     
        public int EntourageId { get; set; }

        public virtual User UserCreator { get; set; }

        public virtual Entourage Entourage { get; set; }

        public virtual ICollection<Event> EventsAsParticipants { get; set; }
    }
}
