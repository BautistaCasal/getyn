﻿using Core.Repository.Queries;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Repository.Services.Event
{
    public interface IEventRepository : IBaseRepository<Entities.Event>
    {
        Task CreateEvent(Entities.Event newEvent, int userId);
        Task<IEnumerable<CountEventsInSectionsModel>> CountBySection();
        Task<IEnumerable<CountEventsInSectionsModel>> CountByDays();
    }
}
