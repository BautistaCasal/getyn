﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Core.Dtos.User.Request
{
    public class CreateUserRequestDto
    {
        [Required]
        public string Username { get; set; }

        [Required]
        public string Password { get; set; }

        [Required]
        public string Email { get; set; }

        [Required]
        public string FirstName { get; set; }

        [Required]
        public string LastName { get; set; }

        public List<int> RolesId { get; set; } = new List<int>();
    }
}
