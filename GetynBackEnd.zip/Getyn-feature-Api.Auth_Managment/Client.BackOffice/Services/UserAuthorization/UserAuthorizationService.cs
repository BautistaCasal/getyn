﻿using System.Collections.Generic;
using System.Security.Claims;
using System.Threading.Tasks;
using Blazored.LocalStorage;
using Client.BackOffice.Services.User;
using Microsoft.AspNetCore.Components.Authorization;

namespace Client.BackOffice.Services.UserAuthorization
{
    public class UserAuthorizationService : AuthenticationStateProvider
    {
        private readonly UserStateService _userState;

        public UserAuthorizationService(ILocalStorageService localStorage, UserStateService userStateService)
        {
            _userState = userStateService;
        }

        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            List<Claim> claims = new();
            if (_userState.User == null)
                return await Task.FromResult(
                    new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity(claims, "No Autorizado"))));
            claims.Add(new Claim(ClaimTypes.Name, _userState.User.Username));
            if(_userState.User.Token.Claims.Count == 1) claims.Add(new Claim(ClaimTypes.Role, "NoRole"));
            foreach (var obj in _userState.User.Token.Claims) claims.Add(new Claim(ClaimTypes.Role, obj.Value));
            var auth = new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity(claims, "BackOfficeGetyn")));
            NotifyAuthenticationStateChanged(Task.FromResult(auth));
            return await Task.FromResult(auth);

        }
    }
}