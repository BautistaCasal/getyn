﻿using Core.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Linq;
using System.Threading.Tasks;
using System.Collections.Generic;
using System.Linq.Expressions;
using System;

namespace Core.Repository.Services
{
    public abstract class BaseRepository<T> : IBaseRepository<T> where T : BaseEntity
    {
        private readonly GetynDBContext _dbContext;
        private readonly IConfiguration _configuration;

        public BaseRepository(IConfiguration configuration, GetynDBContext context)
        {
            _dbContext = context;
            _configuration = configuration;
        }

        public async Task Add(T entity)
        {
            _dbContext.Set<T>().Add(entity);
            await _dbContext.SaveChangesAsync();
        }

        public async Task Delete(int id)
        {
            var entity = await _dbContext.Set<T>().FindAsync(id);
            _dbContext.Set<T>().Remove(entity);
            await _dbContext.SaveChangesAsync();
        }

        public async Task<IEnumerable<T>> GetAll(int take, int skip)
        {
            var query = _dbContext.Set<T>().OrderByDescending( e => e.AddedDate).Skip(skip).Take<T>(take).AsNoTracking();
            return await query.ToListAsync();
        }

        public async Task<IEnumerable<T>> GetAll(int take, int skip, params Expression<Func<T, object>>[] includePaths)
        {
            var query = _dbContext.Set<T>().OrderByDescending(e => e.AddedDate).Skip(skip).Take<T>(take).AsNoTracking();
            foreach (var include in includePaths)
            {
                query = query.Include(include);
            }
            return await query.ToListAsync();
        }

        public async Task<IEnumerable<T>> GetByFilter(int take, int skip, params Expression<Func<T, bool>>[] filters)
        {
            var query = _dbContext.Set<T>().OrderByDescending(e => e.AddedDate).Skip(skip).Take<T>(take).AsNoTracking();
            foreach (var include in filters)
            {
                query = query.Where(include);
            }
            return await query.ToListAsync();
        }
   
        public async Task<T> GetById(int id)
        {
            return await _dbContext.Set<T>().FindAsync(id);
        }

        public async Task<T> GetById(int id, params Expression<Func<T, object>>[] includePaths)
        {
            var query = _dbContext.Set<T>().Where(o => o.Id == id);
            foreach(var include in includePaths)
            {
                query = query.Include(include);
            }
            return await query.FirstOrDefaultAsync();
        }

        public async Task Update(T entity, int id)
        {
            var entityTemp = await _dbContext.Set<T>().FindAsync(id);
            entityTemp = entity;
            await _dbContext.SaveChangesAsync();
        }

        public async Task<long> Count()
        {
            var count = await _dbContext.Set<T>().LongCountAsync();
            return count;
        }
    }
}
