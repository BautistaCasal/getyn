﻿namespace Client.BackOffice.Models
{
    public class MicroserviceModel
    {
        public string Name { get; set; }
        public string Ip { get; set; }
        public string Port { get; set; }
    }
}
