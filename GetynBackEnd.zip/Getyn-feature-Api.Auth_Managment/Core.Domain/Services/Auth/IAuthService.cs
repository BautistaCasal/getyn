﻿using Core.Dtos.Auth.Request;
using Core.Dtos.Auth.Response;
using System.Threading.Tasks;

namespace Core.Domain.Services.Auth
{
    public interface IAuthService
    {
        public Task<AuthenticateResponseDto> Authenticate(AuthenticateRequestDto model);
        public Task<ValidTokenResponseDto> ValidateToken(string token);
    }
}
