﻿using Core.Dtos.File;
using Core.Dtos.Rol;
using System;
using System.Collections.Generic;

namespace Core.Dtos.User
{
    public class UserDto
    {
        public int Id { get; set; }
        public DateTime AddedDate { get; set; }
        public DateTime? ModifiedDate { get; set; }
        public DateTime? DisabledDate { get; set; }
        public string Username { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public virtual FileDto ProfileImage { get; set; }
        public virtual ICollection<RolDto> Roles { get; set; }
    }
}
