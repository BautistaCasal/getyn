﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Core.Dtos.User.Request
{
    public class UpdateRolesInUserRequestDto
    {
        [Required]
        public int UserId { get; set; }
        [Required]
        public List<int> RolesId { get; set; } = new List<int>();
    }
}
