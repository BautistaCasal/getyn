﻿using System;
using Api.Events.Helpers;
using Core.Domain.Models;
using Core.Domain.Services.Event;
using Core.Dtos.Base.Request;
using Core.Dtos.Event.Request;
using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Api.Events.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize]
    public class EventController : ControllerBase
    {
        private readonly ILogService _logService;
        private readonly IEventService _eventService;

        public EventController(ILogService logService, IEventService eventService)
        {
            _logService = logService;
            _eventService = eventService;
        }

        [HttpGet]
        public async Task<ActionResult> GetById(string id)
        {
            await _logService.LogInformation("Get event by ID");
            return Ok(await _eventService.GetById(id));
        }

        [HttpPost]
        public async Task<ActionResult<IEnumerable<Event>>> GetAll(GetAllBaseRequestDto filter)
        {
            await _logService.LogInformation("Get All events");
            return Ok(await _eventService.GetAll(filter));
        }

        [HttpPost]
        public async Task<ActionResult> Count()
        {
            var result = await _eventService.Count();
            await _logService.LogInformation("Count event controller");
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> CountBySections()
        {
            var result = await _eventService.CountBySection();
            await _logService.LogInformation("Count by sections event controller");
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> CountByDays()
        {
            var result = await _eventService.CountByDays();
            await _logService.LogInformation("Count by days event controller");
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> Create(CreateEventRequestDto newEvent)
        {
            await _eventService.CreateEvent(newEvent);
            await _logService.LogInformation("Add new event {Event}", newEvent);
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult> CreateRandom()
        {
            var evt = new CreateEventRequestDto
            {
                MinAge = new Random().Next(17,26),
                MaxAge = new Random().Next(26,50),
                CategoryId = new Random().Next(1,5),
                Description = "Descripcion del evento de prueba, puede ser largo " + DateTime.Now.ToShortDateString(),
                MinParticipants = new Random().Next(1,5),
                MaxParticipants = new Random().Next(5,20),
                MainImageURL = "https://cdn3.vectorstock.com/i/1000x1000/35/52/placeholder-rgb-color-icon-vector-32173552.jpg",
                Tags = "Tag1,Tag2,Tag3",
                UserCreatorId = new Random().Next(4, 9),
                ExpirationDate = DateTime.Now.AddDays(new Random().Next(5,30)),
                Title = "Evento de prueba " + DateTime.Now.ToShortDateString(),

            };
            await _eventService.CreateEvent(evt);
            await _logService.LogInformation("Add new event {Event}", evt);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult<IEnumerable<Event>>> Update()
        {
            await _logService.LogInformation("Get All events");
            return Ok();
        }

        [HttpDelete]
        public async Task<ActionResult> Delete(Event section)
        {
            await _eventService.Delete(section.Id);
            await _logService.LogInformation("Delete a event {Event}", section);
            return Ok();
        }
    }
}
