﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class Business : BaseEntity
    {
        [Column("name")]
        [Required]
        public string Name { get; set; }

        [Column("social_number")]
        [Required]
        public string SocialNumber { get; set; }

        [Column("user_owner_id")]
        [Required]
        public int UserOwnerId { get; set; }

        [ForeignKey("UserOwnerId")]
        public virtual User UserOwner { get; set; }
    }
}
