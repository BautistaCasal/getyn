﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Core.Domain.Models
{
    public class Category : BaseModel
    {
        [Required]
        public string Title { get; set; }

        [Required]
        public string Description { get; set; }

        public int SectionId { get; set; }

        public virtual Section Section { get; set; }

        public virtual ICollection<Event> Events { get; set; }
    }
}
