﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class NightMeetings : BaseEntity
    {
        [Required]
        [Column("location")]
        public string Location { get; set; }

        [Required]
        [Column("start_date")]
        public DateTime? StartDate { get; set; }

        [Required]
        [Column("event_id")]
        public int EventId { get; set; }

        [ForeignKey("EventId")]
        public virtual Event BaseEvent { get; set; }

    }
}
