﻿using Microsoft.EntityFrameworkCore;
using System;

namespace Core.Repository.Entities
{
    public class GetynDBContext : DbContext
    {
        public GetynDBContext(DbContextOptions<GetynDBContext> options) : base(options)
        {
        }

        public DbSet<User> Users { get; set; }
        public DbSet<Rol> Roles { get; set; }
        public DbSet<Section> Sections { get; set; }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Event> Events { get; set; }
        public DbSet<NightMeetings> NightMeetings { get; set; }
        public DbSet<Group> Groups { get; set; }
        public DbSet<Entourage> Entourages { get; set; }
        public DbSet<GroupInEvent> GroupsInEvents { get; set; }
        public DbSet<UserInEvent> UsersInEvents { get; set; }
        public DbSet<File> Files { get; set; }
        public DbSet<ImageInEvent> ImageInEvents { get; set; }
        public DbSet<Business> Businesses { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
        }
    }
}
