﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Core.Repository.Migrations
{
    public partial class ProfileImage : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Users_Files_profile_image_id",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_Users_profile_image_id",
                table: "Users");

            migrationBuilder.AlterColumn<int>(
                name: "profile_image_id",
                table: "Users",
                type: "int",
                nullable: true,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_Users_profile_image_id",
                table: "Users",
                column: "profile_image_id",
                unique: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Files_profile_image_id",
                table: "Users",
                column: "profile_image_id",
                principalTable: "Files",
                principalColumn: "_id",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Users_Files_profile_image_id",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_Users_profile_image_id",
                table: "Users");

            migrationBuilder.AlterColumn<int>(
                name: "profile_image_id",
                table: "Users",
                type: "int",
                nullable: false,
                defaultValue: 0,
                oldClrType: typeof(int),
                oldType: "int",
                oldNullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Users_profile_image_id",
                table: "Users",
                column: "profile_image_id");

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Files_profile_image_id",
                table: "Users",
                column: "profile_image_id",
                principalTable: "Files",
                principalColumn: "_id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
