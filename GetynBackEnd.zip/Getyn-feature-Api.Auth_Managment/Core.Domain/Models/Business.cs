﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain.Models
{
    class Business : BaseModel
    {
        [Required]
        public string Name { get; set; }
        [Required]
        public string SocialNumber { get; set; }
        [Required]
        public int UserOwnerId { get; set; }

        public virtual User UserOwner { get; set; }
    }
}
