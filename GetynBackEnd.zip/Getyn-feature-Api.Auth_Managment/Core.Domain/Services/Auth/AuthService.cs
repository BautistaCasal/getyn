﻿using Core.Domain.Services.Auth.JWT;
using Core.Domain.Services.User;
using Core.Dtos.Auth.Request;
using Core.Dtos.Auth.Response;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace Core.Domain.Services.Auth
{
    public class AuthService : IAuthService
    {
        private readonly IUserService _userService;
        private readonly IConfiguration _configuration;
        private readonly IJwtUtils _jwtUtils;

        public AuthService(IUserService userService, IConfiguration configuration, IJwtUtils jwtUtils)
        {
            _userService = userService;
            _configuration = configuration;
            _jwtUtils = jwtUtils;
        }

        public async Task<AuthenticateResponseDto> Authenticate(AuthenticateRequestDto model)
        {
            var user = await _userService.SearchByCredential(model);
            if (user == null) return null;
            var token = _jwtUtils.GenerateToken(user);
            return new AuthenticateResponseDto(user, token);
        }

        public async Task<ValidTokenResponseDto> ValidateToken(string token)
        {
            var jwtToken = _jwtUtils.GetValidatedToken(token);
            await Task.Delay(1);
            return new ValidTokenResponseDto { User = null, Token = new Dtos.Auth.TokenDto(), Header = jwtToken.Header.Enc };
        }
    }
}
