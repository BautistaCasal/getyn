﻿using System.ComponentModel.DataAnnotations;

namespace Core.Domain.Models
{
    public class ImageInEvent:BaseModel
    {
        public string Title { get; set; }

        public string Description { get; set; }

        [Required]
        public int EventId { get; set; }

        [Required]
        public int ImageFileId { get; set; }

        public Event Event { get; set; }

        public File ImageFile { get; set; }
    }
}
