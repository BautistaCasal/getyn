﻿using Api.Events.Helpers;
using Core.Domain.Services.File;
using Core.Dtos.Base.Request;
using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Api.Events.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize]
    public class FileController : ControllerBase
    {
        private readonly ILogService _logService;
        private readonly IFileService _fileService;

        public FileController(ILogService logService, IFileService fileService)
        {
            _logService = logService;
            _fileService = fileService;
        }

        [HttpPost]
        public async Task<ActionResult> GetAll([FromBody] GetAllBaseRequestDto filter)
        {
            await _logService.LogInformation("Get All files");
            return Ok(await _fileService.GetAll(filter));
        }

        [HttpPost, DisableRequestSizeLimit]
        public async Task<ActionResult> Upload(IEnumerable<IFormFile> files)
        {
            await _logService.LogInformation("Upload File");

            if (files.Any())
            {
                var text = await _fileService.Upload(files);
                return Ok(text);
            }
            else
            {
                return BadRequest();
            }
        }

        [HttpPost, DisableRequestSizeLimit]
        public async Task<ActionResult> Download(int fileId)
        {
            await _logService.LogInformation("Download File");           
            System.IO.FileInfo data = await _fileService.Download(fileId);
            var fileStream = new System.IO.FileStream(data.FullName, System.IO.FileMode.Open);
            return new FileStreamResult(fileStream, "application/octet-stream") { FileDownloadName = data.Name };
        }

        [HttpDelete]
        public async Task<ActionResult> Delete(int fileId)
        {
            await _fileService.Remove(fileId);
            await _logService.LogInformation("Delete a file {FileId}", fileId);
            return Ok();
        }
    }
}
