﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class File : BaseEntity
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string Path { get; set; }
        public virtual User UserProfileImage { get; set; }
    }
}
