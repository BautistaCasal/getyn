﻿using Core.Dtos.Base.Request;
using Microsoft.AspNetCore.Http;
using System.Collections.Generic;
using System.IO;
using System.Threading.Tasks;

namespace Core.Domain.Services.File
{
    public interface IFileService
    {
        Task<List<Models.File>> Upload(IEnumerable<IFormFile> files);
        Task<FileInfo> Download(int fileId);
        Task Remove(int fileId);
        Task<IEnumerable<Repository.Entities.File>> GetAll(GetAllBaseRequestDto filter);
    }
}
