﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Client.BackOffice.Helpers
{
    public static class HttpClientFactory
    {
        public static HttpClient BuildClient(string token = null)
        {
            HttpClient client = new();
            if(token is not null)
            {
                client.DefaultRequestHeaders.Authorization =
                    new AuthenticationHeaderValue(
                        "Bearer", token);
            }
            return client;
        }
    }
}
