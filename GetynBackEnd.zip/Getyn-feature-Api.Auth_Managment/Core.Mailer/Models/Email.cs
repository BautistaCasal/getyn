﻿using FluentEmail.Core.Models;
using System.Collections.Generic;

namespace Core.Mailer.Models
{
    public class Email
    {
        public IEnumerable<Address> EmailAddress { get; set; }
        public string Subject { get; set; }
        public string Body { get; set; }

        public Email(IEnumerable<Address> emailAddress, string subject, string body)
        {
            EmailAddress = emailAddress;
            Subject = subject;
            Body = body;
        }
    }
}
