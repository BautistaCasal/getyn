﻿using Core.Dtos.Api;
using System;

namespace Core.Domain.Services.ApiStatus
{
    public interface IApiStatusService
    {
        int GetTotalRequest();
        void AddOneTotalRequest();
        ApiStatusDto GetApiStatus();
    }
}
