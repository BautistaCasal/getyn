﻿using AutoMapper;
using Core.Dtos.Category.Request;
using Core.Dtos.File;
using Core.Dtos.Rol;
using Core.Dtos.User;
using Core.Repository.Entities;

namespace Core.Domain.Mapper
{
    public class EntitiesProfile : Profile
    {
        public EntitiesProfile()
        {
            #region Entities
            CreateMap<Models.User, User>(MemberList.Destination)
                .ReverseMap();

            CreateMap<Models.Rol, Rol>(MemberList.Destination)
                .ReverseMap();

            CreateMap<Models.Section, Section>(MemberList.Destination)
               .ReverseMap();

            CreateMap<Models.NightMeetings, NightMeetings>(MemberList.Destination)
               .ReverseMap();

            CreateMap<Models.Event, Event>(MemberList.Destination)
               .ReverseMap();

            CreateMap<Models.Category, Category>(MemberList.Destination)
                .ReverseMap();

            CreateMap<Models.Entourage, Entourage>(MemberList.Destination)
               .ReverseMap();

            CreateMap<Models.File, File>(MemberList.Destination)
               .ReverseMap();
            #endregion

            #region DTOS Request
            CreateMap<Models.Category, CreateCategoryRequestDto>()
            .ReverseMap();
            #endregion

            #region DTOS Response
            CreateMap<User, UserDto>()
           .ReverseMap();

            CreateMap<Rol, RolDto>()
           .ReverseMap();

            CreateMap<File, FileDto>()
          .ReverseMap();
            #endregion
        }
    }
}
