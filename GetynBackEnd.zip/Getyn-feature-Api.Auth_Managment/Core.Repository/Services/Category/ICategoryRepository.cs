﻿namespace Core.Repository.Services.Category
{
    public interface ICategoryRepository : IBaseRepository<Entities.Category>
    {

    }
}
