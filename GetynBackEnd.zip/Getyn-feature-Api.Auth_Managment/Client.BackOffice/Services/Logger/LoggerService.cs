﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;
using Client.BackOffice.Helpers;
using Client.BackOffice.Services.User;
using Core.Dtos;
using Microsoft.Extensions.Configuration;
using MudBlazor;

namespace Client.BackOffice.Services.Logger
{
    public class LoggerService
    {
        private readonly string _baseUrl;
        private readonly UserStateService _userStateService;

        public LoggerService(IConfiguration configuration, UserStateService userStateService)
        {
            _userStateService = userStateService;
            _baseUrl = configuration.GetSection("BaseURLApiGetyn").Value + ":" +
                       configuration.GetSection("ApiLoggerPort").Value;
        }

        public async Task<IEnumerable<Core.Logger.Dtos.LogDto>> GetLogs(TableState state)
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User?.Token?.Token);
            using var response = await client.GetAsync(_baseUrl+ "/Logger/GetLogs?skip=" +
                                                               (state.Page * state.PageSize).ToString() + "&take=" + state.PageSize);
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            return System.Text.Json.JsonSerializer.Deserialize<IEnumerable<Core.Logger.Dtos.LogDto>>(content,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }

        public async Task<IEnumerable<Core.Logger.Dtos.LogDto>> GetLogs(int take, int skip)
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User?.Token?.Token);
            using var response = await client.GetAsync(_baseUrl + "/Logger/GetLogs?skip=" +
                                                       (skip).ToString() + "&take=" + take.ToString());
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            return System.Text.Json.JsonSerializer.Deserialize<IEnumerable<Core.Logger.Dtos.LogDto>>(content,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }

        public async Task<IEnumerable<Core.Logger.Dtos.LogsInHours>> CountLogsByHours(int lastDays)
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User?.Token?.Token);
            using var response7 = await client.GetAsync(_baseUrl + "/Logger/CountLogsByHours?lastDays=" + lastDays.ToString());
            var content7 = await response7.Content.ReadAsStringAsync();
            var logsHourse = System.Text.Json.JsonSerializer.Deserialize<IEnumerable<Core.Logger.Dtos.LogsInHours>>(content7, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
            client.Dispose();
            return logsHourse.OrderBy(o => o.Hour).ToList();
        }

        public async Task<int> Count()
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User?.Token?.Token);
            using var response = await client.GetAsync(_baseUrl + "/Logger/CountLogs");
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            return int.Parse(content);
        }
    }
}
