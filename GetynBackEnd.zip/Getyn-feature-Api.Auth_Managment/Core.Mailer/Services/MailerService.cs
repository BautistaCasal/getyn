﻿using Core.Mailer.Interfaces;
using FluentEmail.Core;
using FluentEmail.Core.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Mailer.Services
{
    public class MailerService : IMailerService
    {
        readonly IFluentEmail _fluentEmail;

        public MailerService(IFluentEmail fluentEmail)
        {
            _fluentEmail = fluentEmail;
        }

        public async Task<SendResponse> SendEmail(IEnumerable<Address> emailAddress, string _subject, string _body)
        {
            return await _fluentEmail
                .To(emailAddress)
                .Subject(_subject)
                .Body(_body)
                .SendAsync();
        }

        public async Task<SendResponse> SendEmail(Models.Email email)
        {
            return await _fluentEmail
                .To(email.EmailAddress)
                .Subject(email.Subject)
                .Body(email.Body)
                .SendAsync();
        }
    }
}
