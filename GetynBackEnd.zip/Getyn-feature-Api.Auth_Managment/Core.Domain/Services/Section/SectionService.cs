﻿using AutoMapper;
using Core.Logger.Interfaces;
using Core.Repository.Services.Section;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Domain.Services.Section
{
    public class SectionService : BaseService<SectionRepository, Repository.Entities.Section, Models.Section>, ISectionService
    {
        public SectionService(ISectionRepository baseRepository, IMapper mapper, ILogService logger) : base(baseRepository, mapper, logger)
        {

        }
    }
}
