﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Linq;

namespace Api.Chat.Controllers
{
    [ApiController]
    [Route("ChatService/[action]")]
    public class ChatController : ControllerBase
    {
        public ChatController()
        {
        }

        [HttpGet]
        public ActionResult Get()
        {
            var rng = new Random();
            return Ok(Enumerable.Range(1, 5).Select(index => new
            {
                Date = DateTime.Now.AddDays(index),
                TemperatureC = rng.Next(-20, 55),
                Summary = "Normal"
            })
                .ToArray());
        }
    }
}
