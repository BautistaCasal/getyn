﻿using Api.Events.Helpers;
using AutoMapper;
using Core.Domain.Models;
using Core.Domain.Services.Category;
using Core.Dtos.Base.Request;
using Core.Dtos.Category.Request;
using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Api.Events.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize]
    public class CategoryController : ControllerBase
    {
        private readonly ILogService _logService;
        private readonly ICategoryService _categoryService;
        private readonly IMapper _mapperService;

        public CategoryController(ILogService logService, ICategoryService categoryService, IMapper mapperService)
        {
            _logService = logService;
            _categoryService = categoryService;
            _mapperService = mapperService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Category>>> GetById(string id)
        {
            await _logService.LogInformation("Get category by ID");
            return Ok(await _categoryService.GetById(id));
        }

        [HttpPost]
        public async Task<ActionResult> GetAll([FromBody] GetAllBaseRequestDto filter)
        {
            await _logService.LogInformation("Get All categories");
            return Ok(await _categoryService.GetAll(filter));
        }

        [HttpPost]
        public async Task<ActionResult> Count()
        {
            var result = await _categoryService.Count();
            await _logService.LogInformation("Count category controller");
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> Create(CreateCategoryRequestDto newCategory)
        {
            await _categoryService.Add(_mapperService.Map<Category>(newCategory));
            await _logService.LogInformation("Add new category {Event}", newCategory);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult<IEnumerable<Event>>> Update()
        {
            await _logService.LogInformation("Get All categories");
            return Ok();
        }

        [HttpDelete]
        public async Task<ActionResult> Delete(Category category)
        {
            await _categoryService.Delete(category.Id);
            await _logService.LogInformation("Delete a category {Category}", category);
            return Ok();
        }
    }

}
