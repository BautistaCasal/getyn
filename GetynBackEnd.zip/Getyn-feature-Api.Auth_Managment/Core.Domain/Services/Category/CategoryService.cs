﻿using AutoMapper;
using Core.Logger.Interfaces;
using Core.Repository.Services.Category;

namespace Core.Domain.Services.Category
{
    public class CategoryService : BaseService<CategoryRepository, Repository.Entities.Category, Models.Category>, ICategoryService
    {
        public CategoryService(ICategoryRepository baseRepository, IMapper mapper, ILogService logger) : base(baseRepository, mapper, logger)
        {          
        }
    }
}
