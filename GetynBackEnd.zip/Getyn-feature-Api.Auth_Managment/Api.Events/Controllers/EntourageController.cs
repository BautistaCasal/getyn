﻿using Api.Events.Helpers;
using Core.Domain.Models;
using Core.Domain.Services.Entourage;
using Core.Dtos.Base.Request;
using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Api.Events.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize]
    public class EntourageController : ControllerBase
    {
        private readonly ILogService _logService;
        private readonly IEntourageService _entouragepService;

        public EntourageController(ILogService logService, IEntourageService entouragepService)
        {
            _logService = logService;
            _entouragepService = entouragepService;
        }

        [HttpGet]
        public async Task<ActionResult> GetById(string id)
        {
            await _logService.LogInformation("Get event by Id");
            return Ok(await _entouragepService.GetById(id));
        }

        [HttpPost]
        public async Task<ActionResult> GetAll(GetAllBaseRequestDto filter)
        {
            await _logService.LogInformation("Get All events");
            return Ok(await _entouragepService.GetAll(filter));
        }

        [HttpPost]
        public async Task<ActionResult> Count()
        {
            var result = await _entouragepService.Count();
            await _logService.LogInformation("Count event controller");
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> Create(Entourage newEntourage)
        {
            await _entouragepService.Add(newEntourage);
            await _logService.LogInformation("Add new event {Entourage}", newEntourage);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult> Update()
        {
            await _logService.LogInformation("Get All events");
            return Ok();
        }

        [HttpDelete]
        public async Task<ActionResult> Delete(string id)
        {
            await _entouragepService.Delete(id);
            await _logService.LogInformation("Delete a event {Id}", id);
            return Ok();
        }
    }
}
