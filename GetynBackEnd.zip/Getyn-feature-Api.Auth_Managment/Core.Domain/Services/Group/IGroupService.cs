﻿using Core.Repository.Services.Group;

namespace Core.Domain.Services.Group
{
    public interface IGroupService : IBaseService<IGroupRepository, Repository.Entities.Group, Models.Group>
    {
    }
}
