﻿using AutoMapper;
using Core.Domain.Extensions;
using Core.Dtos.Auth.Request;
using Core.Dtos.User;
using Core.Dtos.User.Request;
using Core.Logger.Interfaces;
using Core.Repository.Services.User;
using System;
using System.Threading.Tasks;

namespace Core.Domain.Services.User
{
    public class UserService : BaseService<UserRepository, Repository.Entities.User, Models.User>, IUserService
    {
        private readonly IUserRepository _userRepository;
        private readonly ILogService _logger;
        private readonly IMapper _mapper;

        public UserService(IUserRepository baseRepository, IMapper mapper, ILogService logger) : base(baseRepository, mapper, logger)
        {
            _userRepository = baseRepository;
            _logger = logger;
            _mapper = mapper;
        }

        public async Task CreateUser(CreateUserRequestDto entity)
        {
            Repository.Entities.User newUser = new()
            {
                Username = entity.Username,
                AddedDate = DateTime.Now,
                Email = entity.Email,
                FirstName = entity.FirstName,
                LastName = entity.LastName,
                Password = entity.Password.HashToPassword()
            };
            await _userRepository.CreateUser(newUser, entity.RolesId);
            await _logger.LogInformation("Domain service - Add new entity {Entity}", entity);
            return;
        }

        public async Task AddRolesToUser(UpdateRolesInUserRequestDto entity)
        {
            await _userRepository.AddRolesToUser(entity.UserId, entity.RolesId);
            await _logger.LogInformation("Domain service - Add new entity {Entity}", entity);
            return;
        }

        public async Task RemoveRolesToUser(UpdateRolesInUserRequestDto entity)
        {
            await _userRepository.RemoveRolesToUser(entity.UserId, entity.RolesId);
            await _logger.LogInformation("Domain service - Add new entity {Entity}", entity);
            return;
        }

        public async Task<UserDto> GetCompleteById(string id)
        {
            var user = await _userRepository.GetCompleteById(int.Parse(id));
            await _logger.LogInformation("Domain service - Get Complete user {Entity}", user);
            return _mapper.Map<UserDto>(user);
        }

        public async Task UpdateProfileImage(UpdateProfileImageRequestDto dto)
        {
            await _userRepository.UpdateProfileImage(dto.ProfileImageId,dto.UserId);
            await _logger.LogInformation("Domain service -UpdateProfileImage {Dto}", dto);
        }

        public async Task<UserDto> SearchByCredential(AuthenticateRequestDto request)
        {
            await _logger.LogInformation("Domain service - Search by credential {Request}", request);
            var user = await _userRepository.SearchByCredential(request.Username);
            if (user == null) return null;
            if (request.Password.VerifyPassword(user.Password)) return _mapper.Map<UserDto>(user);
            return null;
        }
    }
}
