﻿using Core.Repository.Services.Category;

namespace Core.Domain.Services.Category
{
    public interface ICategoryService : IBaseService<ICategoryRepository, Repository.Entities.Category, Models.Category>
    {
    }
}
