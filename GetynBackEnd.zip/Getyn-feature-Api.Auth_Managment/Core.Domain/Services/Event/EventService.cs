﻿using AutoMapper;
using Core.Dtos;
using Core.Dtos.Event.Request;
using Core.Dtos.Event.Response;
using Core.Logger.Interfaces;
using Core.Repository.Services.Event;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core.Domain.Services.Event
{
    public class EventService : BaseService<EventRepository, Repository.Entities.Event, Models.Event>, IEventService
    {
        private readonly IEventRepository _eventRepository;
        private readonly ILogService _logger;

        public EventService(IEventRepository baseRepository, IMapper mapper, ILogService logger) : base(baseRepository, mapper, logger)
        {
            _eventRepository = baseRepository;
            _logger = logger;
        }

        public async Task CreateEvent(CreateEventRequestDto entity)
        {
            Repository.Entities.Event newEvent = new()
            {
                Title = entity.Title,
                AddedDate = DateTime.Now,
                Description = entity.Description,
                ExpirationDate = entity.ExpirationDate,
                UserCreatorId = entity.UserCreatorId,
                MinAge = entity.MinAge,
                MaxAge = entity.MaxAge,
                MinParticipants = entity.MinParticipants,
                MaxParticipants = entity.MaxParticipants,
                MainImageURL = entity.MainImageURL,
                Tags = entity.Tags,
                Location = entity.Location,
                CategoryId = entity.CategoryId
            };
            await _eventRepository.CreateEvent(newEvent, entity.UserCreatorId);
            await _logger.LogInformation("Domain service - Add new entity {Entity}", entity);
            return;
        }

        public async Task<BaseResponseDto<IEnumerable<CountEventInSectionResponseDto>>> CountBySection()
        {
            var result = await _eventRepository.CountBySection();
            var response = result.Select(s => new CountEventInSectionResponseDto { EventsCount = s.EventsCount, SectionName = s.SectionName }).ToList();
            return new BaseResponseDto<IEnumerable<CountEventInSectionResponseDto>> { Data = response, Message = "Ok" };
        }

        public async Task<BaseResponseDto<IEnumerable<CountEventInSectionResponseDto>>> CountByDays()
        {
            var result = await _eventRepository.CountByDays();
            var response = result.Select(s => new CountEventInSectionResponseDto { EventsCount = s.EventsCount, SectionName = s.SectionName }).ToList();
            return new BaseResponseDto<IEnumerable<CountEventInSectionResponseDto>> { Data = response, Message = "Ok" };
        }
    }
}
