﻿using Core.Logger.Dtos;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Logger.Interfaces
{
    public interface ILogService
    {
        Task LogInformation(string messaje);
        Task LogInformation<T>(string messaje, T propertyValue);

        Task LogWarning(string messaje);
        Task LogWarning<T>(string messaje, T propertyValue);

        Task LogError(string messaje);
        Task LogError<T>(string messaje, T propertyValue);

        Task<IEnumerable<Dtos.LogDto>> GetLogs(int skip, int take, DateTime? startDate, DateTime? endDate);
        Task<int> CountLogs(DateTime? startDate, DateTime? endDate);
        Task<IEnumerable<LogsInHours>> GetLogsInHour(int lastDays = 2);
    }
}
