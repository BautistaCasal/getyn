﻿using Core.Dtos.Auth.Response;
using System;

namespace Client.BackOffice.Services.User
{
    public class UserStateService
    {
        private AuthenticateResponseDto _userInSesion;

        public AuthenticateResponseDto User
        {
            get => _userInSesion;
            set
            {
                _userInSesion = value;
                NotifyStateChanged();
            }
        }

        public event Action OnChange;

        private void NotifyStateChanged() => OnChange?.Invoke();
    }
}
