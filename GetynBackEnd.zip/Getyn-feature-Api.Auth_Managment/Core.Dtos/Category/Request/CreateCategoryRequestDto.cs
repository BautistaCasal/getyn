﻿namespace Core.Dtos.Category.Request
{
    public class CreateCategoryRequestDto
    {
        public string Title { get; set; }
        public string Description { get; set; }
        public int SectionId { get; set; }
    }
}
