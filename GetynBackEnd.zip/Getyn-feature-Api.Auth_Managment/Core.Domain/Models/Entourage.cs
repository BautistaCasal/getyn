﻿using System.Collections.Generic;

namespace Core.Domain.Models
{
    public class Entourage: BaseModel
    {
        public string Info { get; set; }

        public ICollection<User> Members { get; set; }

        public ICollection<Group> Groups { get; set; }

        public Entourage()
        {
            this.Members = new HashSet<User>();
            this.Groups = new HashSet<Group>();
        }
    }
}
