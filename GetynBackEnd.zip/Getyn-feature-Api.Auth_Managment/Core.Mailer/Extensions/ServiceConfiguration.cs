﻿using Core.Mailer.Interfaces;
using Core.Mailer.Services;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Core.Mailer.Extensions
{
    public static class ServiceConfiguration
    {
        public static void AddMailerService(this IServiceCollection services, IConfiguration configuration)
        {
            services
            .AddFluentEmail("ccotella@irsacp.com.ar")
            .AddSmtpSender("smtp.sendgrid.net", 25, "apikey", "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");

            services.AddScoped<IMailerService, MailerService>();           
        }
    }
}
