﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Core.Repository.Migrations
{
    public partial class FileEvent2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ImageInEvent_Events_user_id",
                table: "ImageInEvent");

            migrationBuilder.DropForeignKey(
                name: "FK_ImageInEvent_Files_event_id",
                table: "ImageInEvent");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ImageInEvent",
                table: "ImageInEvent");

            migrationBuilder.RenameTable(
                name: "ImageInEvent",
                newName: "ImageInEvents");

            migrationBuilder.RenameIndex(
                name: "IX_ImageInEvent_user_id",
                table: "ImageInEvents",
                newName: "IX_ImageInEvents_user_id");

            migrationBuilder.RenameIndex(
                name: "IX_ImageInEvent_event_id",
                table: "ImageInEvents",
                newName: "IX_ImageInEvents_event_id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ImageInEvents",
                table: "ImageInEvents",
                column: "_id");

            migrationBuilder.AddForeignKey(
                name: "FK_ImageInEvents_Events_user_id",
                table: "ImageInEvents",
                column: "user_id",
                principalTable: "Events",
                principalColumn: "_id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ImageInEvents_Files_event_id",
                table: "ImageInEvents",
                column: "event_id",
                principalTable: "Files",
                principalColumn: "_id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_ImageInEvents_Events_user_id",
                table: "ImageInEvents");

            migrationBuilder.DropForeignKey(
                name: "FK_ImageInEvents_Files_event_id",
                table: "ImageInEvents");

            migrationBuilder.DropPrimaryKey(
                name: "PK_ImageInEvents",
                table: "ImageInEvents");

            migrationBuilder.RenameTable(
                name: "ImageInEvents",
                newName: "ImageInEvent");

            migrationBuilder.RenameIndex(
                name: "IX_ImageInEvents_user_id",
                table: "ImageInEvent",
                newName: "IX_ImageInEvent_user_id");

            migrationBuilder.RenameIndex(
                name: "IX_ImageInEvents_event_id",
                table: "ImageInEvent",
                newName: "IX_ImageInEvent_event_id");

            migrationBuilder.AddPrimaryKey(
                name: "PK_ImageInEvent",
                table: "ImageInEvent",
                column: "_id");

            migrationBuilder.AddForeignKey(
                name: "FK_ImageInEvent_Events_user_id",
                table: "ImageInEvent",
                column: "user_id",
                principalTable: "Events",
                principalColumn: "_id",
                onDelete: ReferentialAction.Cascade);

            migrationBuilder.AddForeignKey(
                name: "FK_ImageInEvent_Files_event_id",
                table: "ImageInEvent",
                column: "event_id",
                principalTable: "Files",
                principalColumn: "_id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
