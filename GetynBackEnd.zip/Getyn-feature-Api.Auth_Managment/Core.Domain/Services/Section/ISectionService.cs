﻿using Core.Repository.Services.Section;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Domain.Services.Section
{
    public interface ISectionService : IBaseService<ISectionRepository, Repository.Entities.Section, Models.Section>
    {

    }
}
