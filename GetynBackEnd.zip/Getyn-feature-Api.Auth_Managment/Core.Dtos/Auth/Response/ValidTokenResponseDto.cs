﻿using Core.Dtos.User;
using System.Collections.Generic;

namespace Core.Dtos.Auth.Response
{
    public class ValidTokenResponseDto
    {
        public UserDto User { get; set; }
        public TokenDto Token { get; set; }
        public string Header { get; set; }
    }
}
