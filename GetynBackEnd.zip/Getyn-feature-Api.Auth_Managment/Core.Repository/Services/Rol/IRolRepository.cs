﻿namespace Core.Repository.Services.Rol
{
    public interface IRolRepository : IBaseRepository<Entities.Rol>
    {

    }
}
