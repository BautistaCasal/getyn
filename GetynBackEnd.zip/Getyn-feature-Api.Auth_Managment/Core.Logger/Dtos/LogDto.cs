﻿using System;

namespace Core.Logger.Dtos
{
    public class LogDto
    {
        public string _id { get; set; }
        public string Level { get; set; }
        public DateTime Timestamp { get; set; }
        public string MessageTemplate { get; set; }
        public string RenderedMessage { get; set; }
    }
}
