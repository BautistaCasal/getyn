﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class Category : BaseEntity
    {
        [Column("title")]
        [Required]
        public string Title { get; set; }

        [Column("description")]
        [Required]
        public string Description { get; set; }

        [Column("section_id")]
        [Required]
        public int SectionId { get; set; }

        [ForeignKey("SectionId")]
        public virtual Section Section { get; set; }

        [InverseProperty("Category")]
        public virtual ICollection<Event> Events { get; set; }
    }
}
