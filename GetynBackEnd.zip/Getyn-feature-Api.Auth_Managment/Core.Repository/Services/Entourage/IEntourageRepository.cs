﻿namespace Core.Repository.Services.Entourage
{
    public interface IEntourageRepository : IBaseRepository<Entities.Entourage>
    {
    }
}
