﻿using System;
using System.ComponentModel;
using System.ComponentModel.DataAnnotations;

namespace Core.Dtos
{
    public class BaseRequestDto
    {
        [Range(1, 1000)]
        [DefaultValue(100)]
        public int Take { get; set; } = 100;

        [Range(0, int.MaxValue)]
        [DefaultValue(0)]
        public int Skip { get; set; } = 0;
    }
}
