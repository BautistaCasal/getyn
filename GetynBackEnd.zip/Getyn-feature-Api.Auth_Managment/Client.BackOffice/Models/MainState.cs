﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Core.Domain.Models;

namespace Client.BackOffice.Models
{
    public class MainState
    {
        public List<User> OnLineUsers { get; set; }
        public List<ChatMessage> Messages { get; set; }

        public MainState()
        {
            OnLineUsers = new List<User>();
            Messages = new List<ChatMessage>();
        }
    }
}
