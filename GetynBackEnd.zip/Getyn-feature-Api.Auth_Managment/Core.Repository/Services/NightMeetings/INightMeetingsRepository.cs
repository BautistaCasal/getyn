﻿namespace Core.Repository.Services.NightMeetings
{
    public interface INightMeetingsRepository : IBaseRepository<Entities.NightMeetings>
    {

    }
}
