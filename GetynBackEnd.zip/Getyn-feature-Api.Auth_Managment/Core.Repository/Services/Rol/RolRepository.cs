﻿using Core.Repository.Entities;
using Microsoft.Extensions.Configuration;

namespace Core.Repository.Services.Rol
{
    public class RolRepository : BaseRepository<Entities.Rol>, IRolRepository
    {
        public RolRepository(IConfiguration configuration, GetynDBContext context) : base(configuration, context)
        {
        }
    }
}
