﻿using Core.Dtos.Auth.Request;
using Core.Dtos.User;
using Core.Dtos.User.Request;
using Core.Repository.Services.User;
using System.Threading.Tasks;

namespace Core.Domain.Services.User
{
    public interface IUserService : IBaseService<IUserRepository, Repository.Entities.User, Models.User>
    {
        Task CreateUser(CreateUserRequestDto entity);
        Task AddRolesToUser(UpdateRolesInUserRequestDto entity);
        Task RemoveRolesToUser(UpdateRolesInUserRequestDto entity);
        Task<UserDto> GetCompleteById(string id);
        Task<UserDto> SearchByCredential(AuthenticateRequestDto request);
        Task UpdateProfileImage(UpdateProfileImageRequestDto dto);
    }
}
