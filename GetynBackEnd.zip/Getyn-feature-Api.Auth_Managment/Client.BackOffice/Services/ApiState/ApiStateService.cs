﻿using Client.BackOffice.Helpers;
using Client.BackOffice.Services.User;
using Core.Dtos;
using Core.Dtos.Api;
using System;
using System.Diagnostics;
using System.Net;
using System.Text.Json;
using System.Threading.Tasks;

namespace Client.BackOffice.Services.ApiState
{
    public class ApiStateService
    {
        private readonly UserStateService _userStateService;

        public ApiStateService(UserStateService userStateService)
        {
            _userStateService = userStateService;
        }

        public async Task<BaseResponseDto<ApiStatusDto>> GetApiStatus(string host)
        {
            var _timer = Stopwatch.StartNew();
            using var client = HttpClientFactory.BuildClient(_userStateService.User?.Token?.Token);
            using var response = await client.GetAsync(host + "/Status/Health");
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            var respObj = JsonSerializer.Deserialize<BaseResponseDto<ApiStatusDto>>(content,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });           
            _timer.Stop();
            respObj.Data.TotalLatency = _timer.ElapsedMilliseconds;
            return respObj;
        }

        public async Task<ApiStatusDto> PingWebService(string url)
        {
            var _timer = Stopwatch.StartNew();
            try
            {
                HttpWebRequest request = (HttpWebRequest)HttpWebRequest.Create(url);
                request.Timeout = 5000;
                request.AllowAutoRedirect = false;
                request.Method = "HEAD";
                using var response = await request.GetResponseAsync();
                _timer.Stop();
                return new ApiStatusDto()
                {
                    Status = "OK",
                    Message = "Everything working properly!",
                    TotalLatency = _timer.ElapsedMilliseconds
                };
            }
            catch(Exception ex)
            {
                return new ApiStatusDto()
                {
                    Status = "Error",
                    Message = ex.Message
                };
            }
        }
    }
}
