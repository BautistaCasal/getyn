﻿using Api.Events.Helpers;
using Core.Domain.Models;
using Core.Domain.Services.Section;
using Core.Dtos.Base.Request;
using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Api.Events.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize]
    public class SectionController : ControllerBase
    {
        private readonly ILogService _logService;
        private readonly ISectionService _sectionService;

        public SectionController(ILogService logService, ISectionService sectionService)
        {
            _logService = logService;
            _sectionService = sectionService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Section>>> GetById(string id)
        {
            await _logService.LogInformation("Get section by ID {Id}", id);
            return Ok(await _sectionService.GetById(id));
        }

        [HttpPost]
        public async Task<ActionResult> GetAll(GetAllBaseRequestDto filter)
        {
            await _logService.LogInformation("Get All sections");
            return Ok(await _sectionService.GetAll(filter));
        }

        [HttpPost]
        public async Task<ActionResult> Count()
        {
            var result = await _sectionService.Count();
            await _logService.LogInformation("Count controller");
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> Create(Section section)
        {
            await _sectionService.Add(section);
            await _logService.LogInformation("Add new section {Section}", section);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult<IEnumerable<Section>>> Update()
        {
            await _logService.LogInformation("Update sections");
            return Ok();
        }

        [HttpDelete]
        public async Task<ActionResult> Delete(Section section)
        {
            await _sectionService.Add(section);
            await _logService.LogInformation("Add new section {Section}", section);
            return Ok();
        }
    }
}
