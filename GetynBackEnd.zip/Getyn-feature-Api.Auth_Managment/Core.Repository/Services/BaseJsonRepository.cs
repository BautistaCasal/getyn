﻿using Core.Repository.Entities;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Core.Repository.Services
{

    public abstract class BaseJsonRepository<T> : IBaseRepository<T> where T : BaseEntity
    {
        public readonly IMongoCollection<T> _entities;

        public BaseJsonRepository(IConfiguration configuration, GetynDBContext context)
        {
            var client = new MongoClient(configuration.GetConnectionString("GetynStringConection"));
            var database = client.GetDatabase(configuration.GetSection("GetynDB").Value);
            var _entities = database.GetCollection<T>(configuration.GetSection(typeof(T).Name + "Col").Value);
        }

        public async Task Add(T entity)
        {
            await Task.Delay(1);
            throw new NotImplementedException();
        }

        public async Task Delete(int id)
        {
            await Task.Delay(1);
            throw new NotImplementedException();
        }

        public async Task<IEnumerable<T>> GetAll(int take, int skip)
        {
            await Task.Delay(1);
            throw new NotImplementedException();
        }

        public async Task<T> GetById(int id)
        {
            await Task.Delay(1);
            throw new NotImplementedException();
        }

        public async Task Update(T entity, int id)
        {
            await Task.Delay(1);
            throw new NotImplementedException();
        }

        public async Task<long> Count()
        {
            await Task.Delay(1);
            throw new NotImplementedException();
        }

        public Task<T> GetById(int id, params Expression<Func<T, object>>[] includePaths)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<T>> GetAll(int take, int skip, params Expression<Func<T, object>>[] includePaths)
        {
            throw new NotImplementedException();
        }

        public Task<IEnumerable<T>> GetByFilter(int take, int skip, params Expression<Func<T, bool>>[] filters)
        {
            throw new NotImplementedException();
        }
    }
}
