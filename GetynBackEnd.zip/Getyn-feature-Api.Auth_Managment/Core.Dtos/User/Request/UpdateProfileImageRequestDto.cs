﻿namespace Core.Dtos.User.Request
{
    public class UpdateProfileImageRequestDto
    {
        public int UserId { get; set; }
        public int ProfileImageId { get; set; }
    }
}
