﻿using Core.Logger.Interfaces;
using Core.Logger.Services;
using Microsoft.Extensions.DependencyInjection;

namespace Core.Logger.Extensions
{
    public static class ServiceConfiguration
    {
		public static void AddLogServices(this IServiceCollection services)
		{
			services.AddSingleton<ILogService, LogService>();
		}
	}
}
