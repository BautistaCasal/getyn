﻿namespace Core.Domain.Models
{
    public class File : BaseModel
    {
        public string Name { get; set; }
        public string Type { get; set; }
        public string Path { get; set; }
        public virtual User UserProfileImage { get; set; }
    }
}
