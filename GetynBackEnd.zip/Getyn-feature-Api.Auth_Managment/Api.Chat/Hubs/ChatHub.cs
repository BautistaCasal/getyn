﻿using Microsoft.AspNetCore.SignalR;
using System.Threading.Tasks;

namespace Api.Chat.Hubs
{
    public class ChatHub : Hub
    {
        public async Task Send(string name, string message)
        {
            await Clients.All.SendAsync("broadcastMessage", name, message);
        }

        public async Task SendMessageToCaller(string user, string message)
        {
            await Clients.Caller.SendAsync("ReceiveMessage", user, message);
        }

        public async Task SendMessageToGroup(int groupId, string user, string message)
        {
            await Clients.Group(groupId.ToString()).SendAsync("ReceiveMessage", user, message);
        }

        public  Task AddToGroup(int groupId)
        {
            return Groups.AddToGroupAsync(Context.ConnectionId, groupId.ToString());
        }

        public Task RemoveFromGroup(int groupId)
        {
            return Groups.RemoveFromGroupAsync(Context.ConnectionId, groupId.ToString());
        }
    }
}
