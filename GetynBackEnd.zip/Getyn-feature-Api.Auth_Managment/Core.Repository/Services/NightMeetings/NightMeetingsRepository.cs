﻿using Core.Repository.Entities;
using Microsoft.Extensions.Configuration;

namespace Core.Repository.Services.NightMeetings
{
    public class NightMeetingsRepository : BaseRepository<Entities.NightMeetings>, INightMeetingsRepository
    {
        public NightMeetingsRepository(IConfiguration configuration, GetynDBContext context) : base(configuration, context)
        {
        }
    }
}
