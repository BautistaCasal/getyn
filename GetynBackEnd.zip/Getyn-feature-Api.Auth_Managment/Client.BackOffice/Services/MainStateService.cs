﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Client.BackOffice.Models;

namespace Client.BackOffice.Services
{
    public class MainStateService
    {
        public MainState AppState;

        public MainStateService()
        {
            AppState = new MainState();
        }

        public event Action OnChange;

        public event Action OnChangeMsj;

        public async Task AgregarNuevoUsuario(Core.Domain.Models.User user)
        {
            await Task.Run(() => AppState.OnLineUsers.Add(user));
            OnChange?.Invoke(); 
        }

        public async Task AgregarNuevoMensaje(ChatMessage msj)
        {
            await Task.Run(() => AppState.Messages.Add(msj));
            if(AppState.Messages.Count > 100) AppState.Messages.RemoveAt(0);
            OnChangeMsj?.Invoke(); 
        }
    }
}
