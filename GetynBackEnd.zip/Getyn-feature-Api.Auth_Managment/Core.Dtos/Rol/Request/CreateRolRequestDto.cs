﻿using System.ComponentModel.DataAnnotations;

namespace Core.Dtos.Rol.Request
{
    public class CreateRolRequestDto
    {
        [Required]
        public string Rolname { get; set; }
        [Required]
        public string Description { get; set; }
    }
}
