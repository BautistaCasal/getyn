﻿namespace Core.Dtos.Rol
{
    public class RolDto
    {
        public int Id { get; set; }
        public string Rolname { get; set; }
        public string Description { get; set; }
    }
}
