﻿using MongoDB.Bson;
using MongoDB.Bson.Serialization.Attributes;
using System;

namespace Core.Logger.Model
{
    [BsonIgnoreExtraElements]
    public class Log
    {
        public ObjectId _id { get; set; }
        public string Level { get; set; }
        [BsonRepresentation(BsonType.DateTime)]
        public DateTime Timestamp { get; set; }
        public string MessageTemplate { get; set; }
        public string RenderedMessage { get; set; }
    }
}
