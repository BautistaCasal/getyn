﻿using System.Threading.Tasks;

namespace Core.Repository.Services.File
{
    public interface IFileRepository : IBaseRepository<Entities.File>
    {
        Task<Entities.File> Upload(string filename, string filetype, string filepath);
    }
}
