﻿namespace Core.Dtos.User.Request
{
    public class UpdateUserRequestDto
    {
    }
}
