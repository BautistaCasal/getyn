﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Dtos.Api
{
    public class ApiStatusDto
    {

        public string ApiName { get; set; }

        public string Status { get; set; }

        public string Message { get; set; }

        public string Ip { get; set; }

        public int Port { get; set; }

        public long TotalLatency { get; set; }

        public long ApiLatency { get; set; }

        public int TotalRequest { get; set; }

        public string TimeOnLine { get; set; }
    }
}
