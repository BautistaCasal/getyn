﻿using Core.Domain.Services.ApiStatus;
using Core.Dtos;
using Core.Dtos.Api;
using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Api.Mailer.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class StatusController : ControllerBase
    {
        private readonly ILogService _logService;
        private readonly IApiStatusService _apiStatusService;

        public StatusController(ILogService logService, IApiStatusService apiStatusService)
        {
            _logService = logService;
            _apiStatusService = apiStatusService;
        }

        [HttpGet]
        public async Task<ActionResult<BaseResponseDto<ApiStatusDto>>> Health()
        {
            await _logService.LogInformation("Check for status. Mailer.API");
            return Ok(new BaseResponseDto<ApiStatusDto>()
            {
                Message = "OK",
                Data = await Task.FromResult(_apiStatusService.GetApiStatus())
            });
        }
    }
}
