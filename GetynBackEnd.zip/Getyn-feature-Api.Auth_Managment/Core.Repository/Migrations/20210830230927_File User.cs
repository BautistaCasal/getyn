﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Core.Repository.Migrations
{
    public partial class FileUser : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            //migrationBuilder.AddColumn<int>(
            //    name: "profile_image_id",
            //    table: "Users",
            //    type: "int",
            //    nullable: false,
            //    defaultValue: 0);

            //migrationBuilder.CreateIndex(
            //    name: "IX_Users_profile_image_id",
            //    table: "Users",
            //    column: "profile_image_id");

            migrationBuilder.AddForeignKey(
                name: "FK_Users_Files_profile_image_id",
                table: "Users",
                column: "profile_image_id",
                principalTable: "Files",
                principalColumn: "_id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Users_Files_profile_image_id",
                table: "Users");

            migrationBuilder.DropIndex(
                name: "IX_Users_profile_image_id",
                table: "Users");

            migrationBuilder.DropColumn(
                name: "profile_image_id",
                table: "Users");
        }
    }
}
