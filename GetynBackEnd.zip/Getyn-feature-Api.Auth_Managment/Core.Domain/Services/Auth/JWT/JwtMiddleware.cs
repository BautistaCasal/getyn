﻿using Core.Domain.Services.ApiStatus;
using Core.Domain.Services.User;
using Microsoft.AspNetCore.Http;
using System;
using System.Linq;
using System.Threading.Tasks;

namespace Core.Domain.Services.Auth.JWT
{
    public class JwtMiddleware
    {
        private readonly RequestDelegate _next;

        public JwtMiddleware(RequestDelegate next)
        {
            _next = next;
        }

        public async Task Invoke(HttpContext context, IUserService userService, IJwtUtils jwtUtils, IApiStatusService apiStatusService)
        {
            apiStatusService.AddOneTotalRequest();
            var token = context.Request.Headers["Authorization"].FirstOrDefault()?.Split(" ").Last();
            if (token == null)
            {
                await _next(context);
                return;
            }
            var validateToken = jwtUtils.ValidateToken(token);
            if (validateToken == null)
            {
                await _next(context);
                return;
            }
            var userId = validateToken.Claims.First(x => x.Type == "user_id").Value;
            var timeTo = validateToken.ValidTo;
            var now = DateTime.Now.ToUniversalTime();
            var time = timeTo.Subtract(now).Minutes;
            if (time < 14)
            {
                context.Items["NewToken"] = "Token a punto de vencer";
            }

            if (int.TryParse(userId, out int id))
            {
                await attachUserToContext(context, userService, userId);
            }          
            await _next(context);
        }

        private async Task attachUserToContext(HttpContext context, IUserService userService, string userId)
        {
            try
            {
                context.Items["User"] = await userService.GetById(userId);
            }
            catch
            {
                //Fail JWT Generation
            }
        }
    }
}
