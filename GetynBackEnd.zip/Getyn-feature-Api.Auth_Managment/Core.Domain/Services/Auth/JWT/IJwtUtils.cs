﻿using Core.Dtos.Auth;
using Core.Dtos.User;
using System.IdentityModel.Tokens.Jwt;

namespace Core.Domain.Services.Auth.JWT
{
    public interface IJwtUtils
    {
        public TokenDto GenerateToken(UserDto user);
        public JwtSecurityToken ValidateToken(string token);
        public JwtSecurityToken GetValidatedToken(string token);
    }
}
