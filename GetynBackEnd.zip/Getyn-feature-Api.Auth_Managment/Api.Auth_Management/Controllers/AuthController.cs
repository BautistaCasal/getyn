﻿using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;
using Api.Auth_Management.Helpers;
using Core.Domain.Services.Auth;
using System.ComponentModel.DataAnnotations;
using Core.Dtos.Auth.Response;
using Core.Dtos.Auth.Request;

namespace Api.Auth_Management.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize]
    public class AuthController : ControllerBase
    {
        readonly ILogService _logService;
        readonly IAuthService _authService;

        public AuthController(ILogService logService, IAuthService authService)
        {
            _logService = logService;
            _authService = authService;
        }
       
        [AllowAnonymous]
        [HttpPost]
        public async Task<ActionResult<AuthenticateResponseDto>> GetToken(AuthenticateRequestDto authenticateRequest)
        {
            await _logService.LogInformation("Get Token: {Request}", authenticateRequest);
            var result = await _authService.Authenticate(authenticateRequest);
            if (result == null) return new NotFoundResult();
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult<ValidTokenResponseDto>> ValidateToken([Required]string token)
        {
            return Ok(await _authService.ValidateToken(token));
        }
    }
}
