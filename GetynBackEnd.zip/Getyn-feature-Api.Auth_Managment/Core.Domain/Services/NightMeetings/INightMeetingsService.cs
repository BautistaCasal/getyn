﻿using Core.Repository.Services.NightMeetings;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain.Services.NightMeetings
{
    public interface INightMeetingsService : IBaseService<INightMeetingsRepository, Repository.Entities.NightMeetings, Models.NightMeetings>
    {
    }
}
