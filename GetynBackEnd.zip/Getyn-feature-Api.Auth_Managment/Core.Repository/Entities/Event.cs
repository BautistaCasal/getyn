﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class Event : BaseEntity
    {
        [Required]
        [Column("title")]
        public string Title { get; set; }

        [Column("description")]
        public string Description { get; set; }

        [Column("expiration_date")]
        public DateTime? ExpirationDate { get; set; }

        [Column("min_age")]
        public int? MinAge { get; set; }

        [Column("max_age")]
        public int? MaxAge { get; set; }

        [Column("min_participants")]
        public int? MinParticipants { get; set; }

        [Column("max_participants")]
        public int? MaxParticipants { get; set; }

        [Column("main_image_url")]
        public string MainImageURL { get; set; }

        [Column("tags")]
        public string Tags { get; set; }

        [Column("location")]
        public string Location { get; set; }

        [Column("user_creator_id")]
        [Required]
        public int UserCreatorId { get; set; }

        [ForeignKey("UserCreatorId")]
        public virtual User UserCreator { get; set; }

        [Column("category_id")]
        [Required]
        public int CategoryId { get; set; }

        [ForeignKey("CategoryId")]
        public virtual Category Category { get; set; }

        [InverseProperty("Event")]
        public virtual ICollection<GroupInEvent> GroupsParticipants { get; set; }

        [InverseProperty("Event")]
        public virtual ICollection<UserInEvent> UsersParticipants { get; set; }

        [InverseProperty("Event")]
        public virtual ICollection<ImageInEvent> ImagesInEvent { get; set; }

        public Event()
        {
            ImagesInEvent = new HashSet<ImageInEvent>();
            GroupsParticipants = new HashSet<GroupInEvent>();
            UsersParticipants = new HashSet<UserInEvent>();
        }
    }
}
