﻿using Core.Domain.Mapper;
using Core.Domain.Services.ApiStatus;
using Core.Domain.Services.Auth;
using Core.Domain.Services.Auth.JWT;
using Core.Domain.Services.Category;
using Core.Domain.Services.Entourage;
using Core.Domain.Services.Event;
using Core.Domain.Services.File;
using Core.Domain.Services.Group;
using Core.Domain.Services.NightMeetings;
using Core.Domain.Services.Rol;
using Core.Domain.Services.Section;
using Core.Domain.Services.User;
using Core.Logger.Extensions;
using Core.Repository.Extensions;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Core.Domain.Extensions
{
    public static class ServiceConfiguration
    {
        public static void AddDomainService(this IServiceCollection services, IConfiguration configuration)
        {
            services.AddSingleton<IApiStatusService, ApiStatusService>();
            services.AddLogServices();
            services.AddScoped<IAuthService, AuthService>();
            services.AddTransient<IJwtUtils, JwtUtils>();
            services.AddRepositoryService(configuration);            
            services.AddAutoMapper(typeof(EntitiesProfile));          
            services.AddScoped<IUserService, UserService>();
            services.AddScoped<ISectionService, SectionService>();
            services.AddScoped<IRolService, RolService>();
            services.AddScoped<IEventService, EventService>();
            services.AddScoped<INightMeetingsService, NightMeetingsService>();
            services.AddScoped<ICategoryService, CategoryService>();
            services.AddScoped<IGroupService,GroupService>();
            services.AddScoped<IEntourageService, EntourageService>();
            services.AddScoped<IFileService, FileService>();
        }
    }
}
