﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class User : BaseEntity
    {
        [Required]
        [Column("user_name")]
        public string Username { get; set; }

        [Required]
        [Column("password")]
        public string Password { get; set; }

        [Required]
        [Column("email")]
        public string Email { get; set; }

        [Column("first_name")]
        public string FirstName { get; set; }

        [Column("last_name")]
        public string LastName { get; set; }

        [Column("profile_image_id")]
        public int? ProfileImageId { get; set; }

        [ForeignKey("ProfileImageId")]
        public virtual File ProfileImage { get; set; }

        public virtual ICollection<Rol> Roles { get; set; }

        public virtual ICollection<Entourage> Entourages { get; set; }

        [InverseProperty("UserCreator")]
        public virtual ICollection<Event> EventsACreator { get; set; }

        [InverseProperty("UserCreator")]
        public virtual ICollection<Group> GroupsAsCreator { get; set; }

        [InverseProperty("User")]
        public virtual ICollection<UserInEvent> EventsAsParticipants { get; set; }

        [InverseProperty("UserOwner")]
        public virtual ICollection<Business> BusinessAsOwner { get; set; }

        public User()
        {
            Roles = new HashSet<Rol>();
            Entourages = new HashSet<Entourage>();
            EventsACreator = new HashSet<Event>();
            GroupsAsCreator = new HashSet<Group>();
            EventsAsParticipants = new HashSet<UserInEvent>();
        }
    }
}
