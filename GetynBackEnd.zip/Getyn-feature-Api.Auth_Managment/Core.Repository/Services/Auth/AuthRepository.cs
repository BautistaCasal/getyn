﻿namespace Core.Repository.Services.Auth
{
    public class AuthRepository
    {
    }
}
