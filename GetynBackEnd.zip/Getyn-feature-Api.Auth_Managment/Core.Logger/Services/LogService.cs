﻿using Core.Logger.Dtos;
using Core.Logger.Interfaces;
using Microsoft.Extensions.Configuration;
using MongoDB.Driver;
using MongoDB.Driver.Linq;
using Serilog;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace Core.Logger.Services
{
    public class LogService : ILogService
    {
        readonly ILogger _logger;
        readonly IConfiguration _configuration;
        readonly IMongoClient _mongoClient;

        public LogService(IConfiguration configuration)
        {
            _mongoClient = new MongoClient(configuration.GetConnectionString("GetynStringConection"));
            Serilog.Debugging.SelfLog.Enable(msg => Debug.WriteLine(msg));
            _configuration = configuration;
            _logger = new LoggerConfiguration()
               .ReadFrom.Configuration(configuration)
                    .CreateLogger();         
        }

        public async Task LogInformation(string msj)
        {
            await Task.Run(() => _logger.Information(msj));
        }

        public async Task LogInformation<T>(string msj, T propertyValue)
        {
            await Task.Run(() => _logger.Information<T>(msj, propertyValue));
        }

        public async Task LogWarning(string msj)
        {
            await Task.Run(() => _logger.Warning(msj));
        }

        public async Task LogWarning<T>(string msj, T propertyValue)
        {
            await Task.Run(() => _logger.Warning<T>(msj, propertyValue));
        }

        public async Task LogError(string msj)
        {
            await Task.Run(() => _logger.Error(msj));
        }

        public async Task LogError<T>(string msj, T propertyValue)
        {
            await Task.Run(() => _logger.Error<T>(msj, propertyValue));
        }

        public async Task<IEnumerable<LogDto>> GetLogs(int skip, int take, DateTime? startDate, DateTime? endDate)
        {
            var database = _mongoClient.GetDatabase(_configuration.GetSection("GetynDB").Value);
            var _entities = database.GetCollection<Model.Log>("logs");
            var query = _entities.AsQueryable().OrderBy( o => o.Timestamp).Skip(skip).Take(take);
            if (startDate.HasValue)
            {
                query.Where(w => w.Timestamp >= startDate.Value);
            }
            if (endDate.HasValue)
            {
                query.Where(w => w.Timestamp <= endDate.Value);
            }
            var result = await query.Take(take).ToListAsync();
            var response = result.Select(
                e => new LogDto
                {
                    Level = e.Level,
                    MessageTemplate = e.MessageTemplate,
                    RenderedMessage = e.RenderedMessage,
                    Timestamp = e.Timestamp,
                    _id = e._id.GetHashCode().ToString()
                }
            ).ToList();
            return response;
        }

        public async Task<IEnumerable<LogsInHours>> GetLogsInHour(int lastDays = 2)
        {
            var database = _mongoClient.GetDatabase(_configuration.GetSection("GetynDB").Value);
            var _entities = database.GetCollection<Model.Log>("logs");
            var query = await _entities.AsQueryable()
                .OrderByDescending(o => o.Timestamp)
                .Where(obj => obj.Timestamp >= DateTime.Now.AddDays(-lastDays))
                .GroupBy(obj => new { obj.Timestamp.Hour })
                .Select(s => new LogsInHours
                {
                    Hour = s.Key.Hour,
                    CountInfoLogs = s.Where( w => w.Level == "Information").Count(),
                    CountErrorLogs = s.Where(w => w.Level == "Error").Count(),
                    CountWarningLogs = s.Where(w => w.Level == "Warning").Count(),
                }
                )
                .ToListAsync();
            return query;
        }

        public async Task<int> CountLogs(DateTime? startDate, DateTime? endDate)
        {
            var database = _mongoClient.GetDatabase(_configuration.GetSection("GetynDB").Value);
            var _entities = database.GetCollection<Model.Log>("logs");
            var query = await _entities.AsQueryable().CountAsync();     
            return query;
        }
    }
}
