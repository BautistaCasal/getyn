﻿using Core.Repository.Entities;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Repository.Services.Group
{
    public class GroupRepository :BaseRepository<Entities.Group>, IGroupRepository
    {
        private readonly GetynDBContext _dbContext;

        public GroupRepository(IConfiguration configuration, GetynDBContext context) : base(configuration, context)
        {
            _dbContext = context;
        }
    }
}
