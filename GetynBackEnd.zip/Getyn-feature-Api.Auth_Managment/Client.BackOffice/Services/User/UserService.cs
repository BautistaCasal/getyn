﻿using System.Collections.Generic;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;
using Client.BackOffice.Helpers;
using Core.Dtos;
using Core.Dtos.Auth.Response;
using Core.Dtos.User.Request;
using Microsoft.Extensions.Configuration;

namespace Client.BackOffice.Services.User
{
    public class UserService
    {
        private readonly string _baseUrl;
        private readonly  UserStateService _userStateService;

        public UserService(IConfiguration configuration, UserStateService userStateService)
        {
            _userStateService = userStateService;
            _baseUrl = configuration.GetSection("BaseURLApiGetyn").Value + ":" +
                       configuration.GetSection("ApiAuthPort").Value;

        }

        public async Task<AuthenticateResponseDto> Authenticate(string username, string password)
        {
            using var client = HttpClientFactory.BuildClient();
            var postBody = new { username, password };
            using var response = await client.PostAsync(_baseUrl+"/Auth/GetToken", JsonContent.Create(postBody));
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            return JsonSerializer.Deserialize<AuthenticateResponseDto>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }

        public async Task<BaseResponseDto<IEnumerable<Core.Domain.Models.User>>> Get(int take, int skip)
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User.Token.Token);
            var postBody = new { take = take, skip = skip };
            using var response = await client.PostAsync(_baseUrl + "/User/GetAll", JsonContent.Create(postBody));
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            return System.Text.Json.JsonSerializer.Deserialize<BaseResponseDto<IEnumerable<Core.Domain.Models.User>>>(content,
                new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }

        public async Task<bool> Create(CreateUserRequestDto newUser)
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User.Token.Token);
            await client.PostAsync(_baseUrl + "/User/Create", JsonContent.Create(newUser));
            client.Dispose();
            return true;
        }

        public async Task<long> Count()
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User.Token.Token);
            using var response = await client.PostAsync(_baseUrl + "/User/Count", JsonContent.Create(new { }));
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            return System.Text.Json.JsonSerializer.Deserialize<BaseResponseDto<long>>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true }).Data;
        }
    }
}
