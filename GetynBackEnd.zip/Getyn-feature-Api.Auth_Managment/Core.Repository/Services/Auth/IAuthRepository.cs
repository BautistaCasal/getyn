﻿namespace Core.Repository.Services.Auth
{
    public interface IAuthRepository
    {

    }
}
