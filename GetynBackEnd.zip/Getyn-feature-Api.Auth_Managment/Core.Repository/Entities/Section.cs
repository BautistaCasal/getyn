﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class Section : BaseEntity
    {
        [Required]
        [Column("title")]
        public string Title { get; set; }

        [Required]
        [Column("description")]
        public string Description { get; set; }

        [InverseProperty("Section")]
        public virtual ICollection<Category> Categories { get; set; }
    }
}
