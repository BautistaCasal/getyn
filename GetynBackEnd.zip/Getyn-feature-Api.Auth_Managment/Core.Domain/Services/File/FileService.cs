﻿using AutoMapper;
using Core.Dtos.Base.Request;
using Core.Logger.Interfaces;
using Core.Repository.Services.File;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.IO;
using System.Net.Http.Headers;
using System.Threading.Tasks;

namespace Core.Domain.Services.File
{
    public class FileService : IFileService
    {
        private readonly IMapper _mapper;
        private readonly ILogService _logger;
        private readonly IConfiguration _configuration;
        private readonly IFileRepository _fileRepository;

        public FileService(IMapper mapper, ILogService logger, IConfiguration configuration, IFileRepository fileRepository)
        {
            _mapper = mapper;
            _logger = logger;
            _configuration = configuration;
            _fileRepository = fileRepository;
        }

        public async Task<IEnumerable<Repository.Entities.File>> GetAll(GetAllBaseRequestDto filter)
        {
            return await _fileRepository.GetAll(filter.Take,filter.Skip);
        }


        public async Task<List<Models.File>> Upload(IEnumerable<IFormFile> files)
        {
            List<Models.File> newFiles = new();
            foreach(var file in files)
            {
                if(file.Length > 0)
                {
                    var fileName = ContentDispositionHeaderValue.Parse(file.ContentDisposition).FileName.Trim('"');                  
                    string path = _configuration.GetSection("FilesPath").Value+ "/" + fileName;
                    using (var stream = new FileStream(path, FileMode.Create))
                    {
                        await file.CopyToAsync(stream);
                    }
                    var fileEnt = await _fileRepository.Upload(file.FileName, file.ContentType, path);
                    newFiles.Add(_mapper.Map<Models.File>(fileEnt));
                }              
            }          
            return newFiles;
        }

        public async Task<FileInfo> Download(int fileId)
        {
            var fileEnt = await _fileRepository.GetById(fileId);
            var file = new FileInfo(fileEnt.Path);
            if (file.Exists)
            {
                return file;
            }
            return null;
        }

        public async Task Remove(int fileId)
        {
            var fileEnt = await _fileRepository.GetById(fileId);
            await _fileRepository.Delete(fileId);
        }
    }
}
