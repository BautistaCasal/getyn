﻿using System.Collections;

namespace Core.Dtos
{
    public class BaseResponseDto<T>
    {
        public int Count
        {
            get
            {
                if (Data is IEnumerable enumerable)
                {
                    int count = 0;
                    foreach (object val in enumerable) count++;
                    return count;
                }
                if (Data == null) return 0;
                return 1;
            }
        }
        public string Message { get; set; }
        public T Data { get; set; }
    }
}
