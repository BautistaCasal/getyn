﻿using Api.Auth_Management.Helpers;
using Core.Domain.Models;
using Core.Domain.Services.User;
using Core.Dtos;
using Core.Dtos.Base.Request;
using Core.Dtos.User;
using Core.Dtos.User.Request;
using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Api.Auth_Management.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize]
    public class UserController : ControllerBase
    {
        readonly ILogService _logService;
        readonly IUserService _userService;

        public UserController(ILogService logService, IUserService userService)
        {
            _logService = logService;
            _userService = userService;
        }

        [HttpGet]
        public async Task<ActionResult<BaseResponseDto<User>>> GetById(string id)
        {
            return Ok(await _userService.GetById(id));
        }

        [HttpGet]
        public async Task<ActionResult<UserDto>> GetCompleteById(string id)
        {
            return Ok(await _userService.GetCompleteById(id));
        }

        [HttpPost]
        public async Task<ActionResult<BaseResponseDto<IEnumerable<User>>>> GetAll(GetAllBaseRequestDto filter)
        {
            Console.WriteLine(User.ToString());
            return Ok(await _userService.GetAll(filter));
        }

        [HttpPost]
        public async Task<ActionResult<BaseResponseDto<IEnumerable<User>>>> GetByFilter(GetAllBaseRequestDto userFilter)
        {
            return Ok(await _userService.GetAll(userFilter));
        }

        [HttpPost]
        public async Task<ActionResult<long>> Count()
        {
            var result = await _userService.Count();
            await _logService.LogInformation("Count controller");
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> Create(CreateUserRequestDto newUser)
        {
            await _userService.CreateUser(newUser);
            await _logService.LogInformation("Usuario creado correctamente {User}", newUser);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult> Update(UpdateUserRequestDto newUser)
        {
            //await _userService.Update(newUser.UpdateUser, newUser.UserId);
            await _logService.LogInformation("Usuario actualizado correctamente {User}", newUser);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult> UpdateProfileImage(UpdateProfileImageRequestDto dto)
        {
            await _userService.UpdateProfileImage(dto);
            await _logService.LogInformation("Profile image updated {Dto}", dto);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult> AddRoles(UpdateRolesInUserRequestDto addRoles)
        {
            await _userService.AddRolesToUser(addRoles);
            await _logService.LogInformation("Actualizacion de roles sobre usuario. Agregar");
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult> RemoveRoles(UpdateRolesInUserRequestDto addRoles)
        {
            await _userService.RemoveRolesToUser(addRoles);
            await _logService.LogInformation("Actualizacion de roles sobre usuario. Remover");
            return Ok();
        }

        [HttpDelete]
        public async Task<ActionResult> Delete(string userId)
        {
            await _userService.Delete(userId);
            await _logService.LogInformation("Usuario eliminado correctamente {User}", userId);
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult> CreateCanniUCAUser()
        {
            try
            {
                var user = new CreateUserRequestDto
                {
                    Username = "canniuca",
                    Password = "canni123",
                    Email = "canniuca.dev@gmail.com",
                    FirstName = "Claudio",
                    LastName = "Cotella",
                    RolesId = new List<int>() {
                        1
                    }
                };
                await _userService.CreateUser(user);
                await _logService.LogInformation("Usuario creado correctamente {User}", user);
                return Ok();
            }
            catch (Exception ex)
            {
                await _logService.LogInformation("Error al crear usuario {Error}", ex);
                throw;
            }
        }

        [HttpPost]
        public async Task<ActionResult> CreateMarianUser()
        {
            try
            {
                var user = new CreateUserRequestDto
                {
                    Username = "Marian",
                    Password = "marian123",
                    Email = "marianoloprety@live.com.ar",
                    FirstName = "Mariano",
                    LastName = "LoPrete",
                    RolesId = new List<int>() {
                        1
                    }
                };

                await _userService.CreateUser(user);
                await _logService.LogInformation("Usuario creado correctamente {User}", user);
                return Ok();
            }
            catch (Exception ex)
            {
                await _logService.LogInformation("Error al crear usuario {Error}", ex);
                throw;
            }
        }
    }
}
