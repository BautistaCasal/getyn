﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class Entourage : BaseEntity
    {
        [Column("info")]
        public string Info { get; set; }

        public ICollection<User> Members { get; set; }

        [InverseProperty("Entourage")]
        public ICollection<Group> Groups { get; set; }

        public Entourage()
        {
            this.Members = new HashSet<User>();
            this.Groups = new HashSet<Group>();
        }
    }
}
