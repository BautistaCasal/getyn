﻿using FluentEmail.Core.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Mailer.Interfaces
{
    public interface IMailerService
    {
        Task<SendResponse> SendEmail(IEnumerable<Address> emailAddress, string _subject, string _body);
        Task<SendResponse> SendEmail(Models.Email email);
    }
}
