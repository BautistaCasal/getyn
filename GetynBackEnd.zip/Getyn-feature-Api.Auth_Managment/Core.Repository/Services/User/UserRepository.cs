﻿using Core.Repository.Entities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core.Repository.Services.User
{
    public class UserRepository : BaseRepository<Entities.User>, IUserRepository
    {
        private readonly GetynDBContext _dbContext;

        public UserRepository(IConfiguration configuration, GetynDBContext context) : base(configuration, context)
        {
            _dbContext = context;
        }

        public async Task CreateUser(Entities.User newUser,List<int> rolesId)
        {
            var user = await _dbContext.Users.AsNoTracking().Where(user => user.Username == newUser.Username || user.Email == newUser.Email).FirstOrDefaultAsync();
            if (user != null) return;
            var roles = await _dbContext.Roles.Where(rol => rolesId.Contains(rol.Id)).ToListAsync();
            newUser.Roles = roles;
            await _dbContext.Users.AddAsync(newUser);
            await _dbContext.SaveChangesAsync();
        }

        public async Task<Entities.User> GetCompleteById(int id)
        {
            var user = await _dbContext.Users
                .AsNoTracking()
                .IgnoreAutoIncludes()
                .Include(i => i.Roles)
                .Include(i => i.Entourages)
                .Include( i => i.ProfileImage)
                .Where(user => user.Id == id)
                .FirstOrDefaultAsync();
            return user;
        }

        public async Task UpdateProfileImage(int imageId, int userId)
        {
            var user = await _dbContext.Users
                .IgnoreAutoIncludes()
                .Where(user => user.Id == userId)
                .FirstOrDefaultAsync();

            user.ProfileImageId = imageId;
            await _dbContext.SaveChangesAsync();
        }

        public async Task AddRolesToUser(int userId, List<int> rolesId)
        {
            var user = await _dbContext.Users.Include("Roles").Where(user => user.Id == userId).FirstOrDefaultAsync();
            if (user == null) return;
            rolesId.RemoveAll(rol => user.Roles.Select(r => r.Id).ToList().Contains(rol));
            var roles = await _dbContext.Roles.Where(rol => rolesId.Contains(rol.Id)).ToListAsync();
            foreach(var rol in roles)
            {
                user.Roles.Add(rol);
            }
            await _dbContext.SaveChangesAsync();
        }

        public async Task RemoveRolesToUser(int userId, List<int> rolesId)
        {
            var user = await _dbContext.Users.Include("Roles").Where(user => user.Id == userId).FirstOrDefaultAsync();
            if (user == null) return;
            var rolesInUser = user.Roles.Where(rol => rolesId.Contains(rol.Id)).ToList();
            foreach(var rolUser in rolesInUser)
            {
                user.Roles.Remove(rolUser);
            }
            await _dbContext.SaveChangesAsync();
        }

        public async Task<Entities.User> SearchByCredential(string username)
        {
            var user = await _dbContext.Users.Include("Roles").Where(user => user.Username.ToLower() == username.ToLower()).FirstOrDefaultAsync();
            return user;
        }
    }
}
