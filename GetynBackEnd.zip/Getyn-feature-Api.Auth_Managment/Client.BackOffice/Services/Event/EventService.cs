﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Net.Http.Json;
using System.Text.Json;
using System.Threading.Tasks;
using Client.BackOffice.Helpers;
using Client.BackOffice.Services.User;
using Core.Dtos;
using Core.Dtos.Event.Response;
using Microsoft.Extensions.Configuration;

namespace Client.BackOffice.Services.Event
{
    public class EventService
    {
        private readonly string _baseUrl;
        private readonly UserStateService _userStateService;

        public EventService(IConfiguration configuration, UserStateService userStateService)
        {
            _userStateService = userStateService;
            _baseUrl = configuration.GetSection("BaseURLApiGetyn").Value + ":" +
                      configuration.GetSection("ApiEventPort").Value;
        }

        public async Task<long> CountSections()
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User?.Token?.Token);
            using var response = await client.PostAsync(_baseUrl+"/Section/Count", JsonContent.Create(new { }));
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            return System.Text.Json.JsonSerializer.Deserialize<BaseResponseDto<long>>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true }).Data;
        }

        public async Task<BaseResponseDto<IEnumerable<CountEventInSectionResponseDto>>> CountEventsByDays()
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User?.Token?.Token);
            using var response = await client.PostAsync(_baseUrl + "/Event/CountByDays", JsonContent.Create(new { }));
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            return System.Text.Json.JsonSerializer.Deserialize<BaseResponseDto<IEnumerable<CountEventInSectionResponseDto>>>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }

        public async Task<long> CountCategories()
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User?.Token?.Token);
            using var response = await client.PostAsync(_baseUrl + "/Category/Count", JsonContent.Create(new { }));
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            return System.Text.Json.JsonSerializer.Deserialize<BaseResponseDto<long>>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true }).Data;
        }

        public async Task<long> CountEvents()
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User?.Token?.Token);
            using var response = await client.PostAsync(_baseUrl + "/Event/Count", JsonContent.Create(new { }));
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            return System.Text.Json.JsonSerializer.Deserialize<BaseResponseDto<long>>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true }).Data;
        }

        public async Task<BaseResponseDto<IEnumerable<CountEventInSectionResponseDto>>> CountEventsBySections()
        {
            using var client = HttpClientFactory.BuildClient(_userStateService.User?.Token?.Token);
            using var response = await client.PostAsync(_baseUrl + "/Event/CountBySections", JsonContent.Create(new { }));
            var content = await response.Content.ReadAsStringAsync();
            client.Dispose();
            return System.Text.Json.JsonSerializer.Deserialize<BaseResponseDto<IEnumerable<CountEventInSectionResponseDto>>>(content, new JsonSerializerOptions { PropertyNameCaseInsensitive = true });
        }
    }
}
