﻿using System;
using Core.Repository.Entities;
using Core.Repository.Queries;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Core.Repository.Services.Event
{
    public class EventRepository : BaseRepository<Entities.Event>, IEventRepository
    {
        private readonly GetynDBContext _dbContext;

        public EventRepository(IConfiguration configuration, GetynDBContext context) : base(configuration, context)
        {
            _dbContext = context;
        }

        public async Task CreateEvent(Entities.Event newEvent, int userId)
        {
            var user = await _dbContext.Users.AsNoTracking().Where(us => us.Id == userId).FirstOrDefaultAsync();
            if (user == null) return;
            await _dbContext.Events.AddAsync(newEvent);
            await _dbContext.SaveChangesAsync();
        }

        public async Task<IEnumerable<CountEventsInSectionsModel>> CountBySection()
        {
            var events = await _dbContext.Events
                .AsNoTracking()
                .Include(e => e.Category)
                .ThenInclude(c => c.Section)
                .GroupBy(e => e.Category.Section.Title)
                .Select(e => new CountEventsInSectionsModel { EventsCount = e.Count(), SectionName = e.Key })
                .ToListAsync();
            return events;
        }

        public async Task<IEnumerable<CountEventsInSectionsModel>> CountByDays()
        {
            var events = await _dbContext.Events
                .AsNoTracking()
                .ToListAsync();
                var re = events.GroupBy(e => e.AddedDate.ToShortDateString())
                .Select(e => new CountEventsInSectionsModel { EventsCount = e.Count(), SectionName = e.Key })
                .ToList();
            return re;
        }
    }
}
