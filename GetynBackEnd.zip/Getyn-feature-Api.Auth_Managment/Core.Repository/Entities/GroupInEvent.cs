﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class GroupInEvent : BaseEntity
    {
        [Column("rol")]
        public string Rol { get; set; }

        [Required]
        [Column("group_id")]
        public int GroupId { get; set; }

        [Required]
        [Column("event_id")]
        public int EventId { get; set; }

        [ForeignKey("GroupId")]
        public Group Group { get; set; }

        [ForeignKey("EventId")]
        public Event Event { get; set; }
    }
}
