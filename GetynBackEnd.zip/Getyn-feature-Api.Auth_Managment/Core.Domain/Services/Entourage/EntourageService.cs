﻿using AutoMapper;
using Core.Logger.Interfaces;
using Core.Repository.Services.Entourage;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core.Domain.Services.Entourage
{
    public class EntourageService : BaseService<EntourageRepository, Repository.Entities.Entourage, Models.Entourage>, IEntourageService
    {
        public EntourageService(IEntourageRepository baseRepository, IMapper mapper, ILogService logger) : base(baseRepository, mapper, logger)
        {
        }
    }
}


