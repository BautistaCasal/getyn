﻿using AutoMapper;
using Core.Logger.Interfaces;
using Core.Repository.Services.NightMeetings;

namespace Core.Domain.Services.NightMeetings
{
    public class NightMeetingsService : BaseService<NightMeetingsRepository, Repository.Entities.NightMeetings, Models.NightMeetings>, INightMeetingsService
    {
        public NightMeetingsService(INightMeetingsRepository baseRepository, IMapper mapper, ILogService logger) : base(baseRepository, mapper, logger)
        {

        }
    }
}
