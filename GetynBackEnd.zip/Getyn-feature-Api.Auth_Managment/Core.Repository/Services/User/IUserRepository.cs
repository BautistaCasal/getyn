﻿using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Repository.Services.User
{
    public interface IUserRepository: IBaseRepository<Entities.User>
    {
        Task CreateUser(Entities.User newUser, List<int> rolesId);
        Task AddRolesToUser(int userId, List<int> rolesId);
        Task RemoveRolesToUser(int userId, List<int> rolesId);
        Task<Entities.User> GetCompleteById(int id);
        Task<Entities.User> SearchByCredential(string username);
        Task UpdateProfileImage(int imageId, int userId);
    }
}
