﻿using Core.Repository.Entities;
using Microsoft.Extensions.Configuration;

namespace Core.Repository.Services.Section
{
    public class SectionRepository : BaseRepository<Entities.Section>, ISectionRepository
    {
        public SectionRepository(IConfiguration configuration, GetynDBContext context) : base(configuration, context)
        {
        }
    }
}
