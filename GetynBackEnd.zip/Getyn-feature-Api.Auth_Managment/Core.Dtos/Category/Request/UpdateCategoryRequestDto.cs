﻿namespace Core.Dtos.Category.Request
{
    public class UpdateCategoryRequestDto
    {
    }
}
