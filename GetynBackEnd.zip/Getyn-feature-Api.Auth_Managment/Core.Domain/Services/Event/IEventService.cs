﻿using Core.Dtos;
using Core.Dtos.Event.Request;
using Core.Dtos.Event.Response;
using Core.Repository.Services.Event;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Domain.Services.Event
{
    public interface IEventService : IBaseService<IEventRepository, Repository.Entities.Event, Models.Event>
    {
        Task CreateEvent(CreateEventRequestDto entity);
        Task<BaseResponseDto<IEnumerable<CountEventInSectionResponseDto>>> CountBySection();
        Task<BaseResponseDto<IEnumerable<CountEventInSectionResponseDto>>> CountByDays();
    }
}
