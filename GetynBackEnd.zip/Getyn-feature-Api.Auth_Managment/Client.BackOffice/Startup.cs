using Blazored.LocalStorage;
using Client.BackOffice.Services;
using Client.BackOffice.Services.ApiState;
using Client.BackOffice.Services.Event;
using Client.BackOffice.Services.Logger;
using Client.BackOffice.Services.User;
using Client.BackOffice.Services.UserAuthorization;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using MudBlazor.Services;

namespace Client.BackOffice
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        public void ConfigureServices(IServiceCollection services)
        {
            services.AddBlazoredLocalStorage();
            services.AddRazorPages();
            services.AddServerSideBlazor();
            services.AddSingleton<MainStateService>();
            services.AddScoped<UserStateService>();
            services.AddScoped<AuthenticationStateProvider, UserAuthorizationService>();
            services.AddTransient<UserService>();
            services.AddTransient<LoggerService>();
            services.AddTransient<EventService>();
            services.AddTransient<ApiStateService>();
            services.AddMudServices();
        }

        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                app.UseExceptionHandler("/Error");
            }

            app.UseStaticFiles();

            app.UseRouting();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapBlazorHub();
                endpoints.MapFallbackToPage("/_Host");
            });
        }
    }
}
