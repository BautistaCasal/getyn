﻿using Api.Events.Helpers;
using Core.Domain.Models;
using Core.Domain.Services.NightMeetings;
using Core.Dtos.Base.Request;
using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Api.Events.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize]
    public class NightMeetingsController : ControllerBase
    {
        private readonly ILogService _logService;
        private readonly INightMeetingsService _nightMeetingsService;

        public NightMeetingsController(ILogService logService, INightMeetingsService nightMeetingsService)
        {
            _logService = logService;
            _nightMeetingsService = nightMeetingsService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<NightMeetings>>> GetById(string id)
        {
            await _logService.LogInformation("Get NightMettings by ID");
            return Ok(await _nightMeetingsService.GetById(id));
        }

        [HttpPost]
        public async Task<ActionResult<IEnumerable<NightMeetings>>> GetAll(GetAllBaseRequestDto filter)
        {
            await _logService.LogInformation("Get All Night Meetings");
            return Ok(await _nightMeetingsService.GetAll(filter));
        }

        [HttpPost]
        public async Task<ActionResult> Count()
        {
            var result = await _nightMeetingsService.Count();
            await _logService.LogInformation("Count controller");
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> Create(NightMeetings nightMeeting)
        {
            await _nightMeetingsService.Add(nightMeeting);
            await _logService.LogInformation("Add new Night Meeting {NightMeeting}", nightMeeting);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult> Update()
        {
            await _logService.LogInformation("Get All Night Meetings");
            return Ok();
        }

        [HttpDelete]
        public async Task<ActionResult> Delete(NightMeetings nightMeeting)
        {
            await _nightMeetingsService.Delete(nightMeeting.Id);
            await _logService.LogInformation("Delete a NightMeeting {NightMeetings}", nightMeeting);
            return Ok();
        }
    }
}
