﻿using System;
using System.Collections.Generic;

namespace Core.Dtos.Auth
{
    public class TokenDto
    {
        public Dictionary<string, string> Claims { get; set; }
        public DateTime ExpireDate { get; set; }
        public string Token { get; set; }
    }
}
