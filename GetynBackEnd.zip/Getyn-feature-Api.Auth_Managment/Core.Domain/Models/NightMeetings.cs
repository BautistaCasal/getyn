﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Core.Domain.Models
{
    public class NightMeetings : Event
    {
        [Required]
        public string Location { get; set; }

        [Required]
        public DateTime? StartDate { get; set; }

        [Required]
        public int EventId { get; set; }

        public virtual Event BaseEvent { get; set; }
    }
}
