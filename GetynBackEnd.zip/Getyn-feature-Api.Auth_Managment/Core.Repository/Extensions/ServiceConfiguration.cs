﻿using Core.Repository.Entities;
using Core.Repository.Services.Category;
using Core.Repository.Services.Entourage;
using Core.Repository.Services.Event;
using Core.Repository.Services.File;
using Core.Repository.Services.Group;
using Core.Repository.Services.NightMeetings;
using Core.Repository.Services.Rol;
using Core.Repository.Services.Section;
using Core.Repository.Services.User;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace Core.Repository.Extensions
{
    public static class ServiceConfiguration
    {
        public static void AddRepositoryService(this IServiceCollection services, IConfiguration configuration )
        {
            services.AddDbContextPool<GetynDBContext>(options => options.UseMySQL(configuration.GetConnectionString("GetynMySql")));
            services.AddTransient<IUserRepository, UserRepository>();
            services.AddTransient<ISectionRepository, SectionRepository>();
            services.AddTransient<IRolRepository, RolRepository>();
            services.AddTransient<IEventRepository, EventRepository>();
            services.AddTransient<INightMeetingsRepository, NightMeetingsRepository>();
            services.AddTransient<ICategoryRepository, CategoryRepository>();
            services.AddTransient<IFileRepository, FileRepository>();
            services.AddTransient<IGroupRepository, GroupRepository>();
            services.AddTransient<IEntourageRepository, EntourageRepository>();
        }
    }
}
