﻿using System;
using System.ComponentModel.DataAnnotations;

namespace Core.Domain.Models
{
    public class BaseModel
    {
        public string Id { get; set; }

        [Required]
        public DateTime AddedDate { get; set; }

        public DateTime? ModifiedDate { get; set; }
        public DateTime? DisabledDate { get; set; }
    }
}
