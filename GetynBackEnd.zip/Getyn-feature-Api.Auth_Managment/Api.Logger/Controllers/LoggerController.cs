﻿using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Threading.Tasks;

namespace Api.Logger.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class LoggerController : ControllerBase
    {
        private readonly ILogService _logService;
        public LoggerController(ILogService logService)
        {
            _logService = logService;
        }

        [HttpGet]
        public async Task<ActionResult> GetLogs(int skip = 0, int take = 200, DateTime? startDate = null, DateTime? endDate = null)
        {
            var result = await _logService.GetLogs(skip,take,startDate,endDate);
            return Ok(result);
        }

        [HttpGet]
        public async Task<ActionResult> CountLogs(DateTime? startDate = null, DateTime? endDate = null)
        {
            var result = await _logService.CountLogs(startDate, endDate);
            return Ok(result);
        }

        [HttpGet]
        public async Task<ActionResult> CountLogsByHours(int lastDays)
        {
            var result = await _logService.GetLogsInHour(lastDays);
            return Ok(result);
        }
    }
}