﻿using Api.Auth_Management.Helpers;
using Core.Domain.Models;
using Core.Domain.Services.Rol;
using Core.Dtos.Base.Request;
using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Api.Auth_Management.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize]
    public class RolController : ControllerBase
    {
        readonly ILogService _logService;
        readonly IRolService _rolService;

        public RolController(ILogService logService, IRolService rolService)
        {
            _logService = logService;
            _rolService = rolService;
        }

        [HttpGet]
        public async Task<ActionResult> GetById(string id)
        {
            return Ok(await _rolService.GetById(id));
        }

        [HttpPost]
        public async Task<ActionResult> GetAll(GetAllBaseRequestDto filter)
        {
            return Ok(await _rolService.GetAll(filter));
        }

        [HttpPost]
        public async Task<ActionResult> GetByFilter(GetAllBaseRequestDto filter)
        {
            var result = await _rolService.GetAll(filter);
            await _logService.LogInformation("Get all");
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> Create(Rol newRol)
        {
            await _rolService.Add(newRol);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult> Update(Rol updateRol, string id)
        {
            await _rolService.Update(updateRol, id);
            return Ok();
        }

        [HttpDelete]
        public async Task<ActionResult> Delete(string id)
        {
            await _rolService.Delete(id);
            return Ok();
        }

        [HttpPost]
        public async Task<ActionResult> Count()
        {
            var result = await _rolService.Count();
            await _logService.LogInformation("Count controller");
            return Ok(result);
        }

    }
}
