﻿using AutoMapper;
using Core.Logger.Interfaces;
using Core.Repository.Services.Rol;

namespace Core.Domain.Services.Rol
{
    public class RolService : BaseService<RolRepository, Repository.Entities.Rol, Models.Rol>, IRolService
    {
        public RolService(IRolRepository baseRepository, IMapper mapper, ILogService logger) : base(baseRepository, mapper, logger)
        {

        }
    }
}
