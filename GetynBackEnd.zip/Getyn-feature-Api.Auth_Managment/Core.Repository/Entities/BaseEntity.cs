﻿using System;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public abstract class BaseEntity
    {
        [Key]
        [Column("_id")]
        public int Id { get; set; }

        [Column("added_date")]
        public DateTime AddedDate { get; set; } = DateTime.Now;

        [Column("modified_date")]
        public DateTime? ModifiedDate { get; set; }

        [Column("disabled_date")]
        public DateTime? DisabledDate { get; set; }
    }
}
