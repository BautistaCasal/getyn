﻿using Microsoft.AspNetCore.Components.Authorization;
using System.Threading.Tasks;

namespace Client.BackOffice.Services.UserAuthorization
{
    interface IUserAuthorizationService
    {
        Task<AuthenticationState> GetAuthenticationStateAsync();
    }
}
