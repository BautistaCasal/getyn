﻿using Core.Repository.Entities;
using Microsoft.Extensions.Configuration;
using System.Threading.Tasks;

namespace Core.Repository.Services.File
{
    public class FileRepository : BaseRepository<Entities.File>, IFileRepository
    {
        protected readonly GetynDBContext _context;

        public FileRepository(IConfiguration configuration, GetynDBContext context) : base(configuration, context)
        {
            _context = context;
        }

        public async Task<Entities.File> Upload(string filename, string filetype, string filepath)
        {
            var file = new Entities.File()
            {
                AddedDate = System.DateTime.Now,
                Name = filename,
                Type = filetype,
                Path = filepath
            };
            var newFile = await _context.Files.AddAsync(file);
            await _context.SaveChangesAsync();
            return newFile.Entity;
        }
    }
}
