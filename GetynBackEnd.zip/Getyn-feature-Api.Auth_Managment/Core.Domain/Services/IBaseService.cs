﻿using Core.Dtos;
using Core.Dtos.Base.Request;
using Core.Repository.Entities;
using Core.Repository.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Domain.Services
{
    public interface IBaseService<TR, TE, TM> where TR : IBaseRepository<TE> where TE : BaseEntity
    {
        public Task Add(TM entity);
        public Task Delete(string id);
        public Task<BaseResponseDto<IEnumerable<TM>>> GetAll(GetAllBaseRequestDto filter);
        public Task<BaseResponseDto<IEnumerable<TM>>> GetByFilter(GetAllBaseRequestDto filter);
        public Task<BaseResponseDto<TM>> GetById(string id);
        public Task Update(TM entity, string id);
        public Task<BaseResponseDto<long>> Count();
    }
}
