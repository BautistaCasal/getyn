﻿using Core.Mailer.Interfaces;
using FluentEmail.Core.Models;
using Microsoft.AspNetCore.Mvc;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Api.Mailer.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    public class MailerController : ControllerBase
    {
        readonly IMailerService _mailerService;

        public MailerController(IMailerService mailer)
        {
            _mailerService = mailer;
        }

        [HttpPost]
        public async Task<ActionResult> SendTestEmail()
        {
            await _mailerService.SendEmail(
                new List<Address>() { 
                    new Address { 
                        EmailAddress = "canniuca.dev@gmail.com" 
                    } 
                },
                "Email de prueba",
                "Este es el cuerpo del email, soporta HTML."
                );
            return Ok("Email de prueba enviado correctamente");
        }
    }
}
