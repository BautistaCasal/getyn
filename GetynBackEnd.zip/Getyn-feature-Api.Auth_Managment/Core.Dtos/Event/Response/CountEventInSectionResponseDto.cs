﻿namespace Core.Dtos.Event.Response
{
    public class CountEventInSectionResponseDto
    {
        public string SectionName { get; set; }
        public int EventsCount { get; set; }
    }
}
