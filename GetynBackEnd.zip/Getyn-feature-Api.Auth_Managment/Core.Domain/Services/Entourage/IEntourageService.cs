﻿using Core.Repository.Services.Entourage;

namespace Core.Domain.Services.Entourage
{
    public interface IEntourageService : IBaseService<IEntourageRepository, Repository.Entities.Entourage, Models.Entourage>
    {
    }
}


