﻿using Core.Repository.Entities;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Core.Repository.Services
{
    public interface IBaseRepository<T> where T : BaseEntity
    {
        Task Add(T entity);
        Task Update(T entity,int id);
        Task Delete(int id);
        Task<T> GetById(int id);
        Task<T> GetById(int id, params Expression<Func<T, object>>[] includePaths);
        Task<IEnumerable<T>> GetAll(int take, int skip);
        Task<IEnumerable<T>> GetAll(int take, int skip, params Expression<Func<T, object>>[] includePaths);
        Task<IEnumerable<T>> GetByFilter(int take, int skip, params Expression<Func<T, bool>>[] filters);
        Task<long> Count();
    }
}
