﻿using System.Collections.Generic;

namespace Core.Domain.Models
{
    public class User : BaseModel
    {
        public string Username { get; set; }
        public string Password { get; set; }
        public string Email { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public int? ProfileImageId { get; set; }


        public virtual File ProfileImage { get; set; }
        public virtual ICollection<Rol> Roles { get; set; }
        public virtual ICollection<Entourage> Entourages { get; set; }
        public virtual ICollection<Event> EventsACreator { get; set; }
        public virtual ICollection<Group> GroupsAsCreator { get; set; }
    }
}
