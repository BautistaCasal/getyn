﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class Rol : BaseEntity
    {
        [Required]
        [Column("rol_name")]
        public string RolName { get; set; }

        [Column("description")]
        public string Description { get; set; }

        public virtual ICollection<User> Users { get; set; }

        public Rol()
        {
            this.Users = new HashSet<User>();
        }
    }
}
