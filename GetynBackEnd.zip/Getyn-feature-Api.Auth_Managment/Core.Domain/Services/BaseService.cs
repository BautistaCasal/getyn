﻿using AutoMapper;
using Core.Dtos;
using Core.Dtos.Base.Request;
using Core.Logger.Interfaces;
using Core.Repository.Entities;
using Core.Repository.Services;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Core.Domain.Services
{
    // Type Repository - Type Entity - Type Model
    public class BaseService<TR, TE, TM> : IBaseService<TR, TE, TM> where TR : IBaseRepository<TE> where TE : BaseEntity
    {
        readonly IBaseRepository<TE> _baseRepository;
        readonly IMapper _mapper;
        readonly ILogService _logger;

        public BaseService(IBaseRepository<TE> baseRepository, IMapper mapper, ILogService logger)
        {
            _baseRepository = baseRepository;
            _mapper = mapper;
            _logger = logger;
        }

        public async Task Add(TM entity)
        {
            await _baseRepository.Add(_mapper.Map<TE>(entity));
            await _logger.LogInformation("Domain service - Add new entity {Entity}", entity);
            return;
        }

        public async Task Delete(string id)
        {
            await _baseRepository.Delete(int.Parse(id));
            await _logger.LogInformation("Domain service - Delete entity {ID}", id);
        }

        public async Task<BaseResponseDto<IEnumerable<TM>>> GetAll(GetAllBaseRequestDto filter)
        {
            var result = await _baseRepository.GetAll(filter.Take, filter.Skip);
            await _logger.LogInformation("Domain service - Get all {Result}", result);
            return new BaseResponseDto<IEnumerable<TM>> { Data = _mapper.Map<IEnumerable<TM>>(result), Message = "Ok" };
        }

        public async Task<BaseResponseDto<IEnumerable<TM>>> GetByFilter(GetAllBaseRequestDto filter)
        {
            var result = await _baseRepository.GetAll(filter.Take, filter.Skip);
            await _logger.LogInformation("Domain service - Get by filter {Result}", result);
            return new BaseResponseDto<IEnumerable<TM>> { Data = _mapper.Map<IEnumerable<TM>>(result), Message = "Ok" };
        }

        public async Task<BaseResponseDto<TM>> GetById(string id)
        {
            var result = await _baseRepository.GetById(int.Parse(id));
            await _logger.LogInformation("Domain service - Get by id {Result}", result);
            return new BaseResponseDto<TM> { Data = _mapper.Map<TM>(result), Message = "Ok" };
        }

        public async Task Update(TM entity, string id)
        {
            await _logger.LogInformation("Domain service - Updateid {Entity}" + id, entity);
            await _baseRepository.Update(_mapper.Map<TE>(entity), int.Parse(id));
        }

        public async Task<BaseResponseDto<long>> Count()
        {
            await _logger.LogInformation("Domain service - Count elements");
            var count = await _baseRepository.Count();
            return new BaseResponseDto<long> { Data = count, Message = "Ok" };
        }
    }
}
