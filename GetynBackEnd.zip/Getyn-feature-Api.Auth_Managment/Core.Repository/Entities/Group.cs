﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class Group : BaseEntity
    {
        [Required]
        [Column("title")]
        public string Title { get; set; }

        [Column("description")]
        public string Description { get; set; }

        [Column("main_image_url")]
        public string MainImageURL { get; set; }

        [Column("user_creator_id")]
        public int UserCreatorId { get; set; }

        [ForeignKey("UserCreatorId")]
        public virtual User UserCreator { get; set; }

        [Column("entourage_id")]
        public int EntourageId { get; set; }

        [ForeignKey("EntourageId")]
        public virtual Entourage Entourage { get; set; }

        [InverseProperty("Group")]
        public virtual ICollection<GroupInEvent> EventsAsParticipants { get; set; }
    }
}
