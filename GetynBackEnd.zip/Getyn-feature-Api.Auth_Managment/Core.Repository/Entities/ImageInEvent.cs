﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace Core.Repository.Entities
{
    public class ImageInEvent : BaseEntity
    {
        [Column("title")]
        public string Title { get; set; }

        [Column("description")]
        public string Description { get; set; }

        [Required]
        [Column("user_id")]
        public int EventId { get; set; }

        [Required]
        [Column("event_id")]
        public int ImageFileId { get; set; }

        [ForeignKey("EventId")]
        public Event Event { get; set; }

        [ForeignKey("ImageFileId")]
        public File ImageFile { get; set; }
    }
}
