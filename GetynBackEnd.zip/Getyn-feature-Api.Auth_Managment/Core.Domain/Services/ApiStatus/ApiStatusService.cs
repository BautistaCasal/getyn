﻿using Core.Dtos.Api;
using Core.Logger.Interfaces;
using System;
using System.Diagnostics;
using System.Net;

namespace Core.Domain.Services.ApiStatus
{
    public class ApiStatusService: IApiStatusService
    {
        private readonly ILogService _logger;
        private int _numberRequest;

        public ApiStatusService(ILogService logger)
        {
            _logger = logger;            
        }

        public int GetTotalRequest()
        {
            return _numberRequest;
        }

        public void AddOneTotalRequest()
        {
            _numberRequest++;
            _logger.LogInformation("New request");
        }

        public ApiStatusDto GetApiStatus()
        {
            var _timer = Stopwatch.StartNew();
            string hostName = Dns.GetHostName(); // Retrive the Name of HOST  
            string myIP = Dns.GetHostByName(hostName).AddressList[0].ToString();
            var status = new ApiStatusDto
            {
                ApiName = "Auth.API",
                Status = "OK",
                Message = "Everything working properly!",
                TimeOnLine = (DateTime.UtcNow - Process.GetCurrentProcess().StartTime.ToUniversalTime()).ToString("c"),
                TotalRequest = GetTotalRequest(),
                Ip = myIP,
                Port = 1001
            };
            _timer.Stop();
            status.ApiLatency = _timer.ElapsedMilliseconds;
            return status;
        }
    }
}
