﻿using Api.Events.Helpers;
using Core.Domain.Models;
using Core.Domain.Services.Group;
using Core.Dtos.Base.Request;
using Core.Logger.Interfaces;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace Api.Events.Controllers
{
    [ApiController]
    [Route("[controller]/[action]")]
    [Authorize]
    public class GroupController : ControllerBase
    {
        private readonly ILogService _logService;
        private readonly IGroupService _groupService;

        public GroupController(ILogService logService, IGroupService groupService)
        {
            _logService = logService;
            _groupService = groupService;
        }

        [HttpGet]
        public async Task<ActionResult> GetById(string id)
        {
            await _logService.LogInformation("Get event by Id");
            return Ok(await _groupService.GetById(id));
        }

        [HttpPost]
        public async Task<ActionResult> GetAll(GetAllBaseRequestDto filter)
        {
            await _logService.LogInformation("Get All events");
            return Ok(await _groupService.GetAll(filter));
        }

        [HttpPost]
        public async Task<ActionResult> Count()
        {
            var result = await _groupService.Count();
            await _logService.LogInformation("Count event controller");
            return Ok(result);
        }

        [HttpPost]
        public async Task<ActionResult> Create(Group newGroup)
        {
            await _groupService.Add(newGroup);
            await _logService.LogInformation("Add new event {Group}", newGroup);
            return Ok();
        }

        [HttpPut]
        public async Task<ActionResult> Update()
        {
            await _logService.LogInformation("Get All events");
            return Ok();
        }

        [HttpDelete]
        public async Task<ActionResult> Delete(Group section)
        {
            await _groupService.Delete(section.Id);
            await _logService.LogInformation("Delete a event {Event}", section);
            return Ok();
        }
    }
}
