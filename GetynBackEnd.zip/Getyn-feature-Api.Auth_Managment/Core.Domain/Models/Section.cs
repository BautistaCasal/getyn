﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;

namespace Core.Domain.Models
{
    public class Section : BaseModel
    {
        [Required]
        public string Title { get; set; }
        public string Description { get; set; }

        public virtual ICollection<Category> Categories { get; set; }
    }
}
