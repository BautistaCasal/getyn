﻿namespace Core.Dtos.Base.Request
{
    public class GetAllBaseRequestDto : BaseRequestDto
    {
    }
}
