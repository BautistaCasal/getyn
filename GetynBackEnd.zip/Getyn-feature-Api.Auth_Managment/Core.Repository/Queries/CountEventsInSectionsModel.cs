﻿namespace Core.Repository.Queries
{
    public class CountEventsInSectionsModel
    {
        public string SectionName { get; set; }
        public int EventsCount { get; set; }
    }
}
