﻿namespace Core.Repository.Services.Group
{
    public interface IGroupRepository : IBaseRepository<Entities.Group>
    {
    }
}
