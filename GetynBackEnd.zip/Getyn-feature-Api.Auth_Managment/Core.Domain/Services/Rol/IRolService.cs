﻿using Core.Repository.Services.Rol;

namespace Core.Domain.Services.Rol
{
    public interface IRolService : IBaseService<IRolRepository, Repository.Entities.Rol, Models.Rol>
    {

    }
}
